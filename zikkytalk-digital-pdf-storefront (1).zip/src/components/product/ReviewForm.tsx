"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

export function ReviewForm({ productId }: { productId: number }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [hover, setHover] = useState(0);
  const [status, setStatus] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [error, setError] = useState("");

  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setStatus("sending");
    setError("");
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        productId,
        rating,
        author: fd.get("author"),
        age: fd.get("age") ? Number(fd.get("age")) : null,
        location: fd.get("location"),
        title: fd.get("title"),
        body: fd.get("body"),
      }),
    });
    if (!res.ok) {
      const j = (await res.json().catch(() => ({}))) as { error?: string };
      setError(j.error ?? "Something went wrong.");
      setStatus("error");
      return;
    }
    setStatus("done");
    router.refresh();
  };

  if (status === "done")
    return (
      <div className="animate-fade-up rounded-[24px] bg-paper p-6 text-center">
        <p className="font-serif text-2xl">Thank you ✦</p>
        <p className="mt-1 text-sm text-muted">Your review is live. You&apos;re helping someone decide.</p>
      </div>
    );

  if (!open)
    return (
      <button
        onClick={() => setOpen(true)}
        className="w-full rounded-full border border-ink py-3.5 text-sm font-semibold transition-colors hover:bg-ink hover:text-paper"
      >
        Write a review
      </button>
    );

  const input =
    "w-full rounded-xl border border-ink/15 bg-paper px-4 py-3 text-sm outline-none transition focus:border-ink";

  return (
    <form onSubmit={submit} className="animate-fade-up space-y-4 rounded-[24px] bg-paper p-6">
      <div>
        <p className="text-sm font-medium">Your rating</p>
        <div className="mt-2 flex gap-1" onMouseLeave={() => setHover(0)}>
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              type="button"
              key={n}
              onMouseEnter={() => setHover(n)}
              onClick={() => setRating(n)}
              className={`text-3xl transition-transform hover:scale-110 ${(hover || rating) >= n ? "text-clay" : "text-ink/15"}`}
              aria-label={`${n} star${n > 1 ? "s" : ""}`}
            >
              ★
            </button>
          ))}
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <input name="author" required maxLength={40} placeholder="First name & initial" className={`${input} sm:col-span-1`} />
        <input name="age" type="number" min={13} max={99} placeholder="Age" className={input} />
        <input name="location" maxLength={40} placeholder="City" className={input} />
      </div>
      <input name="title" required maxLength={80} placeholder="Sum it up in a line" className={input} />
      <textarea name="body" required minLength={10} maxLength={1200} rows={4} placeholder="What did you love? What changed?" className={input} />
      {error && <p className="text-sm text-clay">{error}</p>}
      <div className="flex gap-3">
        <button type="button" onClick={() => setOpen(false)} className="rounded-full px-5 py-3 text-sm font-medium text-muted hover:text-ink">
          Cancel
        </button>
        <button
          disabled={status === "sending"}
          className="flex-1 rounded-full bg-ink py-3 text-sm font-semibold text-paper transition-colors hover:bg-clay disabled:opacity-60"
        >
          {status === "sending" ? "Posting…" : "Post review"}
        </button>
      </div>
    </form>
  );
}
