"use client";

import Image from "next/image";
import { useCallback, useEffect, useState } from "react";
import type { CoverTheme, TocChapter } from "@/db/schema";
import { BookCover } from "./BookCover";

type Props = {
  title: string;
  subtitle: string;
  author: string;
  cover: CoverTheme;
  toc: TocChapter[];
  highlights: string[];
  images: { src: string; alt: string }[];
};

function InsidePreview({ title, cover, toc, highlights }: Pick<Props, "title" | "cover" | "toc" | "highlights">) {
  return (
    <div className="grid h-full w-full grid-cols-2 overflow-hidden rounded-md bg-[#fffdf8] text-ink shadow-[0_30px_60px_-20px_rgba(28,23,20,.4)]">
      <div className="@container relative border-r border-ink/10 p-[7%]">
        <p className="text-[4cqw] font-semibold uppercase tracking-[0.25em]" style={{ color: cover.accent }}>
          Contents
        </p>
        <p className="mt-[6%] font-serif text-[9cqw] leading-tight">{title}</p>
        <ol className="mt-[8%] space-y-[5%]">
          {toc.map((c, i) => (
            <li key={c.title} className="flex items-baseline gap-[3%] text-[4.4cqw]">
              <span className="font-serif" style={{ color: cover.accent }}>
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="flex-1 leading-snug">{c.title}</span>
              <span className="text-ink/50">{c.pages.split("–")[0]}</span>
            </li>
          ))}
        </ol>
        <div className="pointer-events-none absolute inset-y-0 right-0 w-6 bg-gradient-to-l from-ink/10 to-transparent" />
      </div>
      <div className="@container relative p-[7%]">
        <p className="text-[4cqw] font-semibold uppercase tracking-[0.25em] text-ink/50">Chapter 01</p>
        <p className="mt-[6%] font-serif text-[8cqw] leading-tight">{toc[0]?.title}</p>
        <div className="mt-[6%] space-y-[3%]">
          {[92, 100, 86, 97, 70].map((w, i) => (
            <div key={i} className="h-[1.6cqw] rounded-full bg-ink/10" style={{ width: `${w}%` }} />
          ))}
        </div>
        <div className="mt-[8%] rounded-lg p-[6%]" style={{ background: cover.bg }}>
          <p className="text-[3.8cqw] font-semibold uppercase tracking-[0.2em]" style={{ color: cover.accent }}>
            Checklist
          </p>
          <ul className="mt-[4%] space-y-[3%]">
            {highlights.slice(0, 3).map((h) => (
              <li key={h} className="flex gap-[4%] text-[3.8cqw] leading-snug" style={{ color: cover.fg }}>
                <span className="mt-[1%] inline-block h-[3.4cqw] w-[3.4cqw] shrink-0 rounded-sm border" style={{ borderColor: cover.accent }} />
                {h}
              </li>
            ))}
          </ul>
        </div>
        <div className="mt-[8%] space-y-[3%]">
          {[100, 88, 94].map((w, i) => (
            <div key={i} className="h-[1.6cqw] rounded-full bg-ink/10" style={{ width: `${w}%` }} />
          ))}
        </div>
        <div className="pointer-events-none absolute inset-y-0 left-0 w-6 bg-gradient-to-r from-ink/10 to-transparent" />
      </div>
    </div>
  );
}

export function Gallery(props: Props) {
  const { title, subtitle, author, cover, images } = props;
  const slides = [
    { kind: "cover" as const, label: "Cover" },
    { kind: "inside" as const, label: "Look inside" },
    ...images.map((img) => ({ kind: "image" as const, label: img.alt, img })),
  ];
  const [i, setI] = useState(0);
  const go = useCallback((d: number) => setI((x) => (x + d + slides.length) % slides.length), [slides.length]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.closest("input,textarea,select")) return;
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go]);

  return (
    <div className="lg:sticky lg:top-28">
      <div
        className="relative aspect-square overflow-hidden rounded-[32px]"
        style={{ background: `radial-gradient(120% 120% at 30% 20%, ${cover.bg}, ${cover.accent}40)` }}
      >
        {slides.map((s, idx) => (
          <div
            key={idx}
            className={`absolute inset-0 grid place-items-center transition-all duration-700 ease-[cubic-bezier(.22,1,.36,1)] ${
              idx === i ? "scale-100 opacity-100" : "pointer-events-none scale-[1.03] opacity-0"
            }`}
            aria-hidden={idx !== i}
          >
            {s.kind === "cover" && (
              <div className="w-[52%] transition-transform duration-700 hover:[transform:perspective(1400px)_rotateY(-16deg)]">
                <BookCover title={title} subtitle={subtitle} author={author} cover={cover} />
              </div>
            )}
            {s.kind === "inside" && (
              <div className="aspect-[3/2] w-[84%]">
                <InsidePreview {...props} />
              </div>
            )}
            {s.kind === "image" && (
              <>
                <Image src={s.img.src} alt={s.img.alt} fill sizes="(max-width:1024px) 100vw, 50vw" className="object-cover" />
                <div className="absolute bottom-[10%] right-[8%] w-[24%] rotate-6">
                  <BookCover title={title} author={author} cover={cover} />
                </div>
              </>
            )}
          </div>
        ))}

        <div className="absolute left-4 top-4 rounded-full bg-paper/90 px-3 py-1 text-xs font-medium backdrop-blur">
          {slides[i].kind === "image" ? "In real life" : slides[i].label}
        </div>
        <div className="absolute bottom-4 right-4 flex gap-2">
          <button
            onClick={() => go(-1)}
            className="grid h-10 w-10 place-items-center rounded-full bg-paper/90 backdrop-blur transition hover:bg-paper"
            aria-label="Previous image"
          >
            ←
          </button>
          <button
            onClick={() => go(1)}
            className="grid h-10 w-10 place-items-center rounded-full bg-paper/90 backdrop-blur transition hover:bg-paper"
            aria-label="Next image"
          >
            →
          </button>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-4 gap-3">
        {slides.map((s, idx) => (
          <button
            key={idx}
            onClick={() => setI(idx)}
            className={`relative aspect-square overflow-hidden rounded-2xl transition-all duration-300 ${
              idx === i ? "ring-2 ring-ink ring-offset-2 ring-offset-cream" : "opacity-70 hover:opacity-100"
            }`}
            style={{ background: cover.bg }}
            aria-label={`Show ${s.label}`}
          >
            {s.kind === "cover" && (
              <div className="absolute inset-0 grid place-items-center">
                <div className="w-[50%]">
                  <BookCover title={title} cover={cover} shadow={false} />
                </div>
              </div>
            )}
            {s.kind === "inside" && (
              <div className="absolute inset-0 grid place-items-center p-2">
                <div className="grid aspect-[3/2] w-full grid-cols-2 gap-px rounded bg-ink/10 shadow">
                  <div className="space-y-1 rounded-l bg-white p-1.5">
                    {[80, 60, 70, 50].map((w) => (
                      <div key={w} className="h-0.5 rounded bg-ink/30" style={{ width: `${w}%` }} />
                    ))}
                  </div>
                  <div className="rounded-r bg-white p-1.5">
                    <div className="h-3 rounded-sm" style={{ background: cover.bg }} />
                  </div>
                </div>
              </div>
            )}
            {s.kind === "image" && <Image src={s.img.src} alt="" fill sizes="120px" className="object-cover" />}
          </button>
        ))}
      </div>
    </div>
  );
}
