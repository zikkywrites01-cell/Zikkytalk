import Link from "next/link";
import type { Product } from "@/lib/data";
import { BookCover } from "./BookCover";
import { Stars } from "@/components/ui/Stars";
import { QuickAddButton } from "@/components/cart/AddToCartButton";
import { formatPrice } from "@/lib/pricing";
import { COLLECTION_NAMES, toCartItem } from "@/lib/cart-item";

export function ProductCard({ product: p, priority = false }: { product: Product; priority?: boolean }) {
  const off = p.compareAtCents ? Math.round((1 - p.priceCents / p.compareAtCents) * 100) : 0;
  return (
    <Link href={`/products/${p.slug}`} className="group block" prefetch={priority ? true : undefined}>
      <div
        className="relative overflow-hidden rounded-[28px] px-[16%] pb-[18%] pt-[14%] transition-colors duration-500"
        style={{ background: `linear-gradient(160deg, ${p.cover.bg}cc, ${p.cover.accent}33)` }}
      >
        <div className="absolute left-4 top-4 z-10 flex flex-wrap gap-1.5">
          {p.bestseller && (
            <span className="rounded-full bg-ink px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-paper">
              Bestseller
            </span>
          )}
          {p.isNew && (
            <span className="rounded-full bg-paper px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-ink">
              New
            </span>
          )}
          {off > 0 && (
            <span className="rounded-full bg-clay px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wider text-paper">
              −{off}%
            </span>
          )}
        </div>
        <BookCover title={p.title} subtitle={p.subtitle} author={p.author} cover={p.cover} tilt />
        <div className="absolute inset-x-4 bottom-4 z-10 translate-y-0 opacity-100 transition-all duration-500 lg:translate-y-4 lg:opacity-0 lg:group-hover:translate-y-0 lg:group-hover:opacity-100">
          <QuickAddButton item={toCartItem(p)} />
        </div>
      </div>
      <div className="mt-4 px-1">
        <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted">
          {COLLECTION_NAMES[p.collectionSlug] ?? p.collectionSlug} · {p.format}
        </p>
        <div className="mt-1.5 flex items-start justify-between gap-3">
          <h3 className="font-serif text-xl leading-tight transition-colors group-hover:text-clay">{p.title}</h3>
          <div className="shrink-0 text-right">
            <p className="font-semibold">{formatPrice(p.priceCents)}</p>
            {p.compareAtCents && <p className="text-xs text-muted line-through">{formatPrice(p.compareAtCents)}</p>}
          </div>
        </div>
        <p className="mt-1 line-clamp-1 text-sm text-muted">{p.subtitle}</p>
        <div className="mt-2 flex items-center gap-2 text-xs text-muted">
          <Stars rating={p.rating} size={13} />
          <span>
            {p.rating.toFixed(1)} ({p.reviewCount})
          </span>
          <span className="text-ink/20">•</span>
          <span>{p.pages} pages</span>
        </div>
      </div>
    </Link>
  );
}
