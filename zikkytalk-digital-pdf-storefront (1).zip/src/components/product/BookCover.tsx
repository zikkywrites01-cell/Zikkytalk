import type { CoverTheme } from "@/db/schema";

function Pattern({ theme }: { theme: CoverTheme }) {
  const { accent, fg } = theme;
  switch (theme.pattern) {
    case "orbit":
      return (
        <g fill="none" stroke={accent} strokeWidth="1.4">
          {[40, 70, 100, 130, 160, 190].map((r) => (
            <circle key={r} cx="230" cy="330" r={r} opacity={1 - r / 260} />
          ))}
          <circle cx="230" cy="330" r="22" fill={accent} stroke="none" />
          <circle cx="132" cy="268" r="6" fill={fg} stroke="none" opacity=".6" />
        </g>
      );
    case "grid":
      return (
        <g stroke={accent} strokeWidth="0.8" opacity=".55">
          {Array.from({ length: 9 }).map((_, i) => (
            <line key={`v${i}`} x1={i * 40} y1="200" x2={i * 40} y2="400" />
          ))}
          {Array.from({ length: 6 }).map((_, i) => (
            <line key={`h${i}`} x1="0" y1={200 + i * 40} x2="300" y2={200 + i * 40} />
          ))}
          <rect x="160" y="240" width="80" height="80" fill={accent} opacity="1" stroke="none" />
          <rect x="200" y="200" width="40" height="40" fill={accent} opacity=".5" stroke="none" />
        </g>
      );
    case "wave":
      return (
        <g fill="none" stroke={accent} strokeWidth="2" strokeLinecap="round">
          {Array.from({ length: 7 }).map((_, i) => (
            <path
              key={i}
              d={`M-10 ${250 + i * 22} C 60 ${225 + i * 22}, 110 ${280 + i * 22}, 180 ${250 + i * 22} S 290 ${225 + i * 22}, 320 ${250 + i * 22}`}
              opacity={0.35 + i * 0.1}
            />
          ))}
        </g>
      );
    case "arch":
      return (
        <g>
          <path d="M40 400 V300 a80 80 0 0 1 160 0 V400 Z" fill={accent} />
          <path d="M150 400 V320 a60 60 0 0 1 120 0 V400 Z" fill={fg} opacity=".12" />
          <circle cx="120" cy="300" r="14" fill={theme.bg} />
        </g>
      );
    case "stripe":
      return (
        <g>
          {Array.from({ length: 6 }).map((_, i) => (
            <rect key={i} x={170 + i * 22} y={220 + (i % 2) * 30} width="10" height="200" rx="5" fill={accent} opacity={0.4 + i * 0.1} />
          ))}
          <circle cx="70" cy="320" r="34" fill="none" stroke={accent} strokeWidth="2" />
        </g>
      );
    case "sun":
      return (
        <g>
          {Array.from({ length: 13 }).map((_, i) => {
            const a = Math.PI + (i * Math.PI) / 12;
            return (
              <line
                key={i}
                x1={150 + Math.cos(a) * 92}
                y1={400 + Math.sin(a) * 92}
                x2={150 + Math.cos(a) * 150}
                y2={400 + Math.sin(a) * 150}
                stroke={accent}
                strokeWidth="2.5"
                strokeLinecap="round"
              />
            );
          })}
          <circle cx="150" cy="400" r="78" fill={accent} />
        </g>
      );
    case "blob":
      return (
        <g>
          <path
            d="M210 230c40 10 80 50 70 100s-60 80-110 70-90-40-80-90 40-75 70-82c15-3 30-1 50 2z"
            fill={accent}
          />
          <path d="M60 300c20-10 50 0 52 22s-20 40-42 36-30-48-10-58z" fill={fg} opacity=".14" />
        </g>
      );
    case "stack":
    default:
      return (
        <g>
          {Array.from({ length: 5 }).map((_, i) => (
            <rect key={i} x={110 + i * 6} y={360 - i * 26} width={150 - i * 12} height="20" rx="10" fill={accent} opacity={1 - i * 0.15} />
          ))}
          <circle cx="60" cy="350" r="18" fill="none" stroke={accent} strokeWidth="2" />
        </g>
      );
  }
}

export function BookCover({
  title,
  subtitle,
  author,
  cover,
  className = "",
  tilt = false,
  shadow = true,
}: {
  title: string;
  subtitle?: string;
  author?: string;
  cover: CoverTheme;
  className?: string;
  tilt?: boolean;
  shadow?: boolean;
}) {
  return (
    <div
      className={`book @container relative aspect-[3/4] w-full overflow-hidden rounded-r-md rounded-l-[3px] ${
        tilt ? "book-tilt" : ""
      } ${shadow ? "shadow-[0_30px_60px_-20px_rgba(28,23,20,.45),0_8px_20px_-8px_rgba(28,23,20,.25)]" : ""} ${className}`}
      style={{ background: cover.bg, color: cover.fg }}
      role="img"
      aria-label={`${title} cover`}
    >
      <svg viewBox="0 0 300 400" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 h-full w-full" aria-hidden>
        <Pattern theme={cover} />
      </svg>
      <div className="relative flex h-full flex-col p-[8%]">
        <div className="flex items-center justify-between text-[3.6cqw] font-semibold uppercase tracking-[0.25em] opacity-80">
          <span>Zikkytalk</span>
          <span className="rounded-full border px-[2.5cqw] py-[0.6cqw]" style={{ borderColor: cover.fg + "55" }}>
            PDF
          </span>
        </div>
        <h3 className="mt-[10%] font-serif text-[12.5cqw] leading-[0.95] font-semibold tracking-tight text-balance">
          {title}
        </h3>
        {subtitle && <p className="mt-[5%] max-w-[85%] text-[4.4cqw] leading-snug opacity-75">{subtitle}</p>}
        {author && (
          <p className="mt-auto text-[3.8cqw] font-medium uppercase tracking-[0.2em] opacity-80">{author}</p>
        )}
      </div>
      {/* spine */}
      <div className="pointer-events-none absolute inset-y-0 left-0 w-[5%] bg-gradient-to-r from-black/25 via-white/15 to-transparent" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/15 via-transparent to-black/10" />
    </div>
  );
}
