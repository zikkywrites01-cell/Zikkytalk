"use client";

import { useEffect, useState } from "react";
import { useCart, type CartItem } from "@/components/cart/CartProvider";
import { formatPrice } from "@/lib/pricing";
import { BookCover } from "./BookCover";

export function StickyBuyBar({ item, anchorId }: { item: CartItem; anchorId: string }) {
  const [show, setShow] = useState(false);
  const { add, has, hydrated, setOpen } = useCart();
  const inCart = hydrated && has(item.slug);

  useEffect(() => {
    const el = document.getElementById(anchorId);
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setShow(!e.isIntersecting && e.boundingClientRect.top < 0));
    io.observe(el);
    return () => io.disconnect();
  }, [anchorId]);

  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-30 border-t border-ink/10 bg-paper/95 backdrop-blur-xl transition-transform duration-500 ${
        show ? "translate-y-0" : "translate-y-full"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 sm:px-6 lg:px-8">
        <div className="w-10 shrink-0">
          <BookCover title={item.title} cover={item.cover} shadow={false} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate font-serif text-lg leading-tight">{item.title}</p>
          <p className="text-sm text-muted">{formatPrice(item.priceCents)} · Instant PDF</p>
        </div>
        <button
          onClick={() => (inCart ? setOpen(true) : add(item))}
          className="rounded-full bg-ink px-6 py-3 text-sm font-semibold text-paper transition-colors hover:bg-clay"
        >
          {inCart ? "View bag" : "Add to bag"}
        </button>
      </div>
    </div>
  );
}
