"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { CoverTheme } from "@/db/schema";

export type CartItem = {
  productId: number;
  slug: string;
  title: string;
  subtitle: string;
  author: string;
  priceCents: number;
  compareAtCents: number | null;
  pages: number;
  format: string;
  cover: CoverTheme;
};

type CartState = {
  items: CartItem[];
  promo: string;
  open: boolean;
  hydrated: boolean;
  justAdded: string | null;
  add: (item: CartItem, opts?: { open?: boolean }) => void;
  remove: (slug: string) => void;
  clear: () => void;
  has: (slug: string) => boolean;
  setPromo: (code: string) => void;
  setOpen: (open: boolean) => void;
};

const CartContext = createContext<CartState | null>(null);
const KEY = "zikkytalk-cart-v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [promo, setPromoState] = useState("");
  const [open, setOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [justAdded, setJustAdded] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as { items?: CartItem[]; promo?: string };
        // eslint-disable-next-line react-hooks/set-state-in-effect
        if (Array.isArray(parsed.items)) setItems(parsed.items);
        if (typeof parsed.promo === "string") setPromoState(parsed.promo);
      }
    } catch {
      /* ignore corrupt storage */
    }
    setHydrated(true);
    const onStorage = (e: StorageEvent) => {
      if (e.key !== KEY || !e.newValue) return;
      try {
        const parsed = JSON.parse(e.newValue) as { items?: CartItem[]; promo?: string };
        setItems(parsed.items ?? []);
        setPromoState(parsed.promo ?? "");
      } catch {}
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(KEY, JSON.stringify({ items, promo }));
  }, [items, promo, hydrated]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  const add = useCallback((item: CartItem, opts?: { open?: boolean }) => {
    setItems((prev) => (prev.some((i) => i.slug === item.slug) ? prev : [...prev, item]));
    setJustAdded(item.slug);
    setTimeout(() => setJustAdded((s) => (s === item.slug ? null : s)), 1800);
    if (opts?.open !== false) setOpen(true);
  }, []);

  const remove = useCallback((slug: string) => setItems((prev) => prev.filter((i) => i.slug !== slug)), []);
  const clear = useCallback(() => {
    setItems([]);
    setPromoState("");
  }, []);
  const has = useCallback((slug: string) => items.some((i) => i.slug === slug), [items]);
  const setPromo = useCallback((code: string) => setPromoState(code.trim().toUpperCase()), []);

  const value = useMemo(
    () => ({ items, promo, open, hydrated, justAdded, add, remove, clear, has, setPromo, setOpen }),
    [items, promo, open, hydrated, justAdded, add, remove, clear, has, setPromo],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
