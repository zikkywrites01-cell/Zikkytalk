"use client";

import Link from "next/link";
import { useEffect } from "react";
import { useCart } from "./CartProvider";
import { BookCover } from "@/components/product/BookCover";
import { computeTotals, formatPrice } from "@/lib/pricing";

export function CartDrawer() {
  const { items, open, setOpen, remove, promo } = useCart();
  const t = computeTotals(
    items.map((i) => i.priceCents),
    promo,
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setOpen]);

  const next = items.length < 2 ? 2 : items.length < 3 ? 3 : null;
  const progress = Math.min(1, items.length / 3);

  return (
    <div className={`fixed inset-0 z-50 ${open ? "" : "pointer-events-none"}`} aria-hidden={!open}>
      <div
        onClick={() => setOpen(false)}
        className={`absolute inset-0 bg-ink/40 backdrop-blur-[2px] transition-opacity duration-500 ${
          open ? "opacity-100" : "opacity-0"
        }`}
      />
      <aside
        role="dialog"
        aria-label="Shopping bag"
        className={`absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-paper shadow-2xl transition-transform duration-500 ease-[cubic-bezier(.22,1,.36,1)] ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between border-b border-ink/10 px-6 py-5">
          <h2 className="font-serif text-2xl">
            Your bag <span className="text-base text-muted">({items.length})</span>
          </h2>
          <button onClick={() => setOpen(false)} className="rounded-full p-2 hover:bg-sand" aria-label="Close cart">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>

        {items.length > 0 && (
          <div className="border-b border-ink/10 bg-cream px-6 py-4">
            <p className="text-sm">
              {next ? (
                <>
                  Add <strong>{next - items.length}</strong> more guide{next - items.length > 1 ? "s" : ""} to save{" "}
                  <strong className="text-clay">{next === 2 ? "10%" : "20%"}</strong>
                </>
              ) : (
                <>
                  🎉 You&apos;ve unlocked <strong className="text-clay">20% bundle savings</strong>
                </>
              )}
            </p>
            <div className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-ink/10">
              <div
                className="h-full rounded-full bg-clay transition-all duration-700"
                style={{ width: `${progress * 100}%` }}
              />
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <div className="relative mb-8 h-40 w-32">
                <div className="absolute inset-0 rotate-[-8deg] rounded-md bg-sand" />
                <div className="absolute inset-0 rotate-[6deg] rounded-md bg-blush" />
                <div className="absolute inset-0 grid place-items-center rounded-md bg-paper font-serif text-4xl shadow-lg">
                  ✦
                </div>
              </div>
              <p className="font-serif text-2xl">Your bag is empty</p>
              <p className="mt-2 max-w-xs text-sm text-muted">
                Our guides are instant downloads — start reading in under a minute.
              </p>
              <Link
                href="/shop"
                onClick={() => setOpen(false)}
                className="mt-6 rounded-full bg-ink px-6 py-3 text-sm font-medium text-paper transition-transform hover:scale-[1.03]"
              >
                Browse the shop
              </Link>
            </div>
          ) : (
            <ul className="divide-y divide-ink/10">
              {items.map((i) => (
                <li key={i.slug} className="flex animate-fade-up gap-4 py-5">
                  <Link href={`/products/${i.slug}`} onClick={() => setOpen(false)} className="w-20 shrink-0">
                    <BookCover title={i.title} cover={i.cover} shadow={false} className="shadow-md" />
                  </Link>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <Link
                          href={`/products/${i.slug}`}
                          onClick={() => setOpen(false)}
                          className="font-serif text-lg leading-tight hover:text-clay"
                        >
                          {i.title}
                        </Link>
                        <p className="mt-1 text-xs text-muted">
                          {i.format} · {i.pages} pages · PDF
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{formatPrice(i.priceCents)}</p>
                        {i.compareAtCents && (
                          <p className="text-xs text-muted line-through">{formatPrice(i.compareAtCents)}</p>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => remove(i.slug)}
                      className="mt-auto self-start text-xs font-medium text-muted underline-offset-4 hover:text-clay hover:underline"
                    >
                      Remove
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t border-ink/10 px-6 py-5">
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted">Subtotal</dt>
                <dd>{formatPrice(t.subtotal)}</dd>
              </div>
              {t.bundleDiscount > 0 && (
                <div className="flex justify-between text-sage">
                  <dt>Bundle savings ({t.bundlePercent}%)</dt>
                  <dd>−{formatPrice(t.bundleDiscount)}</dd>
                </div>
              )}
              {t.promoDiscount > 0 && (
                <div className="flex justify-between text-sage">
                  <dt>Promo {promo}</dt>
                  <dd>−{formatPrice(t.promoDiscount)}</dd>
                </div>
              )}
              <div className="flex justify-between pt-2 font-serif text-xl">
                <dt>Total</dt>
                <dd>{formatPrice(t.total)}</dd>
              </div>
            </dl>
            <Link
              href="/checkout"
              onClick={() => setOpen(false)}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-full bg-ink py-4 text-sm font-semibold text-paper transition-all hover:bg-clay"
            >
              Checkout securely
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M13 6l6 6-6 6" />
              </svg>
            </Link>
            <p className="mt-3 text-center text-xs text-muted">Instant download · 14-day money-back guarantee</p>
          </div>
        )}
      </aside>
    </div>
  );
}
