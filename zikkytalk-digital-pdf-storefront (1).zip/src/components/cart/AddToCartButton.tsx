"use client";

import { useRouter } from "next/navigation";
import { useCart, type CartItem } from "./CartProvider";
import { formatPrice } from "@/lib/pricing";

export function QuickAddButton({ item }: { item: CartItem }) {
  const { add, has, hydrated, setOpen } = useCart();
  const inCart = hydrated && has(item.slug);
  return (
    <button
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        if (inCart) setOpen(true);
        else add(item);
      }}
      className={`flex w-full items-center justify-center gap-2 rounded-full py-3 text-sm font-semibold shadow-lg transition-all duration-300 ${
        inCart ? "bg-paper text-ink" : "bg-ink text-paper hover:bg-clay"
      }`}
      aria-label={inCart ? `${item.title} is in your bag` : `Add ${item.title} to bag`}
    >
      {inCart ? (
        <>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
            <path d="M5 12l5 5L20 7" />
          </svg>
          In your bag
        </>
      ) : (
        <>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 5v14M5 12h14" />
          </svg>
          Quick add
        </>
      )}
    </button>
  );
}

export function AddToCartPanel({ item }: { item: CartItem }) {
  const { add, has, hydrated, setOpen } = useCart();
  const router = useRouter();
  const inCart = hydrated && has(item.slug);

  return (
    <div className="flex flex-col gap-3 sm:flex-row">
      <button
        onClick={() => (inCart ? setOpen(true) : add(item))}
        className={`group flex flex-1 items-center justify-center gap-2 rounded-full py-4 text-sm font-semibold transition-all duration-300 active:scale-[0.98] ${
          inCart ? "border border-ink bg-transparent text-ink hover:bg-ink hover:text-paper" : "bg-ink text-paper hover:bg-clay"
        }`}
      >
        {inCart ? (
          <>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <path d="M5 12l5 5L20 7" />
            </svg>
            In your bag — view
          </>
        ) : (
          <>Add to bag — {formatPrice(item.priceCents)}</>
        )}
      </button>
      <button
        onClick={() => {
          add(item, { open: false });
          router.push("/checkout");
        }}
        className="flex flex-1 items-center justify-center gap-2 rounded-full bg-clay py-4 text-sm font-semibold text-paper transition-all hover:bg-clay-dark active:scale-[0.98]"
      >
        Buy now
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M5 12h14M13 6l6 6-6 6" />
        </svg>
      </button>
    </div>
  );
}
