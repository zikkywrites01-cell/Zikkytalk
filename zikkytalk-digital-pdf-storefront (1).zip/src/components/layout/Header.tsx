"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { useCart } from "@/components/cart/CartProvider";

export const NAV_COLLECTIONS = [
  { slug: "money-moves", name: "Money Moves" },
  { slug: "career-glow-up", name: "Career Glow-Up" },
  { slug: "mind-and-wellness", name: "Mind & Wellness" },
  { slug: "love-and-friendships", name: "Love & Friendships" },
  { slug: "side-hustle-lab", name: "Side Hustle Lab" },
];

const MESSAGES = [
  "Instant download — read on any device",
  "Bundle 2 guides, save 10% · 3+ guides, save 20%",
  "New here? Use WELCOME5 for $5 off",
];

export function Header() {
  const { items, setOpen, hydrated, justAdded } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [menu, setMenu] = useState(false);
  const [search, setSearch] = useState(false);
  const [q, setQ] = useState("");
  const [msg, setMsg] = useState(0);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    const t = setInterval(() => setMsg((m) => (m + 1) % MESSAGES.length), 4200);
    return () => {
      window.removeEventListener("scroll", onScroll);
      clearInterval(t);
    };
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMenu(false);
    setSearch(false);
  }, [pathname]);

  const onSearch = (e: FormEvent) => {
    e.preventDefault();
    router.push(q.trim() ? `/shop?q=${encodeURIComponent(q.trim())}` : "/shop");
  };

  const count = hydrated ? items.length : 0;
  const isCheckout = pathname.startsWith("/checkout");

  return (
    <>
      <div className="bg-ink text-paper">
        <div className="mx-auto flex h-9 max-w-7xl items-center justify-center px-4 text-[11px] font-medium uppercase tracking-[0.2em]">
          <span key={msg} className="animate-fade-in truncate">
            {MESSAGES[msg]}
          </span>
        </div>
      </div>
      <header
        className={`sticky top-0 z-40 transition-all duration-500 ${
          scrolled ? "border-b border-ink/10 bg-cream/85 backdrop-blur-xl" : "bg-cream"
        }`}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:h-20 lg:px-8">
          <button
            className="-ml-2 rounded-full p-2 lg:hidden"
            onClick={() => setMenu((m) => !m)}
            aria-label="Toggle menu"
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
              {menu ? <path d="M6 6l12 12M18 6L6 18" /> : <path d="M4 8h16M4 16h16" />}
            </svg>
          </button>

          <Link href="/" className="font-serif text-2xl font-semibold tracking-tight lg:text-[28px]">
            zikkytalk<span className="text-clay">.</span>
          </Link>

          <nav className="ml-10 hidden items-center gap-8 text-sm font-medium lg:flex">
            <Link href="/shop" className="link-underline hover:text-clay transition-colors">
              Shop all
            </Link>
            <div className="group relative">
              <button className="flex items-center gap-1 transition-colors hover:text-clay">
                Collections
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M6 9l6 6 6-6" />
                </svg>
              </button>
              <div className="invisible absolute left-1/2 top-full z-50 w-64 -translate-x-1/2 translate-y-2 pt-4 opacity-0 transition-all duration-300 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
                <div className="rounded-2xl border border-ink/10 bg-paper p-2 shadow-xl">
                  {NAV_COLLECTIONS.map((c) => (
                    <Link
                      key={c.slug}
                      href={`/collections/${c.slug}`}
                      className="block rounded-xl px-4 py-2.5 text-sm transition-colors hover:bg-sand"
                    >
                      {c.name}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
            <Link href="/shop?tag=bestseller" className="transition-colors hover:text-clay">
              Bestsellers
            </Link>
            <Link href="/shop?tag=new" className="transition-colors hover:text-clay">
              New in
            </Link>
            <Link href="/shop?tag=sale" className="text-clay transition-colors hover:text-clay-dark">
              On sale
            </Link>
          </nav>

          <div className="ml-auto flex items-center gap-1">
            <button
              onClick={() => setSearch((s) => !s)}
              className="rounded-full p-2.5 transition-colors hover:bg-sand"
              aria-label="Search"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                <circle cx="11" cy="11" r="7" />
                <path d="M20 20l-3.5-3.5" />
              </svg>
            </button>
            {!isCheckout && (
              <button
                onClick={() => setOpen(true)}
                className="relative flex items-center gap-2 rounded-full bg-ink py-2.5 pl-4 pr-5 text-sm font-medium text-paper transition-transform hover:scale-[1.03] active:scale-95"
                aria-label={`Open cart, ${count} items`}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
                  <path d="M6 7h12l-1 13H7L6 7z" />
                  <path d="M9 7a3 3 0 016 0" />
                </svg>
                <span className="hidden sm:inline">Bag</span>
                <span
                  key={`${count}-${justAdded}`}
                  className={`grid h-5 min-w-5 place-items-center rounded-full bg-clay px-1 text-[11px] font-semibold ${
                    justAdded ? "animate-pop" : ""
                  }`}
                >
                  {count}
                </span>
              </button>
            )}
          </div>
        </div>

        {/* search */}
        <div
          className={`overflow-hidden border-ink/10 transition-all duration-500 ${
            search ? "max-h-28 border-t" : "max-h-0"
          }`}
        >
          <form onSubmit={onSearch} className="mx-auto flex max-w-3xl items-center gap-3 px-4 py-5">
            <input
              autoFocus={search}
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search guides — try 'budget', 'interview', 'journal'…"
              className="w-full border-b border-ink/30 bg-transparent py-2 font-serif text-xl outline-none placeholder:text-muted/70 focus:border-ink"
            />
            <button className="rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-paper">Search</button>
          </form>
        </div>

        {/* mobile menu */}
        <div
          className={`overflow-hidden transition-all duration-500 lg:hidden ${
            menu ? "max-h-[600px] border-t border-ink/10" : "max-h-0"
          }`}
        >
          <nav className="flex flex-col gap-1 px-4 py-4">
            {[
              { href: "/shop", label: "Shop all" },
              { href: "/shop?tag=bestseller", label: "Bestsellers" },
              { href: "/shop?tag=new", label: "New in" },
              { href: "/shop?tag=sale", label: "On sale" },
            ].map((l) => (
              <Link key={l.href} href={l.href} className="rounded-xl px-3 py-3 font-serif text-2xl hover:bg-sand">
                {l.label}
              </Link>
            ))}
            <p className="mt-4 px-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted">Collections</p>
            {NAV_COLLECTIONS.map((c) => (
              <Link key={c.slug} href={`/collections/${c.slug}`} className="rounded-xl px-3 py-2.5 text-base hover:bg-sand">
                {c.name}
              </Link>
            ))}
          </nav>
        </div>
      </header>
    </>
  );
}
