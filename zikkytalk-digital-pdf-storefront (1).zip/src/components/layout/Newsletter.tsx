"use client";

import { useState, type FormEvent } from "react";

export function Newsletter({ dark = true }: { dark?: boolean }) {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) return;
    setDone(true);
  };

  if (done)
    return (
      <p className={`mt-8 animate-fade-up rounded-2xl px-5 py-4 text-sm ${dark ? "bg-paper/10" : "bg-ink/5"}`}>
        You&apos;re in ✦ Check your inbox for a welcome gift — code <strong>WELCOME5</strong>.
      </p>
    );

  return (
    <form onSubmit={submit} className={`mt-8 flex max-w-md items-center rounded-full p-1.5 ${dark ? "bg-paper/10" : "bg-ink/5"}`}>
      <input
        type="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@email.com"
        className="min-w-0 flex-1 bg-transparent px-4 text-sm outline-none placeholder:opacity-50"
      />
      <button className="rounded-full bg-clay px-5 py-2.5 text-sm font-medium text-paper transition-colors hover:bg-clay-dark">
        Subscribe
      </button>
    </form>
  );
}
