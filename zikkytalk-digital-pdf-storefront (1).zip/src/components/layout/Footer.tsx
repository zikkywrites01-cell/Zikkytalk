import Link from "next/link";
import { Newsletter } from "./Newsletter";

const COLS = [
  {
    title: "Shop",
    links: [
      { href: "/shop", label: "All guides" },
      { href: "/shop?tag=bestseller", label: "Bestsellers" },
      { href: "/shop?tag=new", label: "New in" },
      { href: "/shop?tag=sale", label: "On sale" },
    ],
  },
  {
    title: "Collections",
    links: [
      { href: "/collections/money-moves", label: "Money Moves" },
      { href: "/collections/career-glow-up", label: "Career Glow-Up" },
      { href: "/collections/mind-and-wellness", label: "Mind & Wellness" },
      { href: "/collections/love-and-friendships", label: "Love & Friendships" },
      { href: "/collections/side-hustle-lab", label: "Side Hustle Lab" },
    ],
  },
  {
    title: "Help",
    links: [
      { href: "/#faq", label: "FAQ" },
      { href: "/#faq", label: "Downloads & devices" },
      { href: "/#faq", label: "14-day guarantee" },
      { href: "mailto:hello@zikkytalk.com", label: "hello@zikkytalk.com" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="relative mt-24 overflow-hidden bg-ink text-paper">
      <div className="mx-auto max-w-7xl px-4 pb-10 pt-20 sm:px-6 lg:px-8">
        <div className="grid gap-14 lg:grid-cols-[1.4fr_2fr]">
          <div>
            <p className="font-serif text-4xl leading-tight sm:text-5xl">
              Real talk for your <em className="text-blush">twenties</em>, every Sunday.
            </p>
            <p className="mt-4 max-w-md text-sm text-paper/60">
              One email a week: money tips, career scripts, gentle reminders and early access to new guides. No spam,
              ever.
            </p>
            <Newsletter />
          </div>
          <div className="grid grid-cols-2 gap-10 sm:grid-cols-3">
            {COLS.map((c) => (
              <div key={c.title}>
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-paper/50">{c.title}</p>
                <ul className="mt-5 space-y-3 text-sm">
                  {c.links.map((l) => (
                    <li key={l.label}>
                      <Link href={l.href} className="text-paper/80 transition-colors hover:text-blush">
                        {l.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-20 select-none font-serif text-[22vw] leading-[0.8] tracking-tighter text-paper/[0.06] lg:text-[16rem]">
          zikkytalk.
        </div>
        <div className="mt-6 flex flex-col gap-4 border-t border-paper/10 pt-6 text-xs text-paper/50 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Zikkytalk. Digital products — no physical items will be shipped.</p>
          <div className="flex gap-5">
            <span>Secure checkout</span>
            <span>Instant delivery</span>
            <span>14-day guarantee</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
