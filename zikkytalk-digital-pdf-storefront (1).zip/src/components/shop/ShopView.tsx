import { getCollections, getProducts } from "@/lib/data";
import { ProductCard } from "@/components/product/ProductCard";
import { ShopControls, type ShopParams } from "./ShopControls";

export type RawSearchParams = Record<string, string | string[] | undefined>;

const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? null;
const list = (v: string | string[] | undefined) =>
  (one(v) ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
const num = (v: string | string[] | undefined) => {
  const n = Number(one(v));
  return one(v) && Number.isFinite(n) ? n : null;
};

export function parseShopParams(sp: RawSearchParams, forcedCollection?: string): ShopParams {
  const tag = one(sp.tag);
  return {
    collection: forcedCollection ? [forcedCollection] : list(sp.collection),
    format: list(sp.format),
    level: list(sp.level),
    max: num(sp.max),
    rating: num(sp.rating),
    tag: tag === "new" || tag === "bestseller" || tag === "sale" ? tag : null,
    q: one(sp.q)?.slice(0, 80) || null,
    sort: one(sp.sort) ?? "popular",
  };
}

export async function ShopView({ params, hideCollection = false }: { params: ShopParams; hideCollection?: boolean }) {
  const [products, collections] = await Promise.all([
    getProducts({
      collection: params.collection,
      format: params.format,
      level: params.level,
      maxPrice: params.max ?? undefined,
      minRating: params.rating ?? undefined,
      tag: (params.tag as "new" | "bestseller" | "sale" | null) ?? undefined,
      q: params.q ?? undefined,
      sort: params.sort,
    }),
    getCollections(),
  ]);

  return (
    <ShopControls
      params={params}
      collections={collections.map((c) => ({ slug: c.slug, name: c.name, productCount: c.productCount }))}
      hideCollection={hideCollection}
      total={products.length}
    >
      {products.length > 0 && (
        <div className="grid grid-cols-1 gap-x-6 gap-y-12 sm:grid-cols-2 xl:grid-cols-3">
          {products.map((p, i) => (
            <div key={p.id} className="animate-fade-up" style={{ animationDelay: `${Math.min(i, 8) * 50}ms` }}>
              <ProductCard product={p} />
            </div>
          ))}
        </div>
      )}
    </ShopControls>
  );
}
