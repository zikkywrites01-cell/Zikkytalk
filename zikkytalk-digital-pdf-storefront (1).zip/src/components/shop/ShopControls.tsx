"use client";

import { usePathname, useRouter } from "next/navigation";
import { useState, useTransition, type ReactNode } from "react";

export type ShopParams = {
  collection: string[];
  format: string[];
  level: string[];
  max: number | null;
  rating: number | null;
  tag: string | null;
  q: string | null;
  sort: string;
};

const FORMATS = ["Guide", "Workbook", "Templates", "Journal", "Planner"];
const LEVELS = ["Beginner", "Intermediate", "All levels"];
const TAGS = [
  { v: "bestseller", l: "Bestsellers" },
  { v: "new", l: "New in" },
  { v: "sale", l: "On sale" },
];
export const SORTS = [
  { v: "popular", l: "Most popular" },
  { v: "newest", l: "Newest" },
  { v: "rating", l: "Top rated" },
  { v: "price-asc", l: "Price: low to high" },
  { v: "price-desc", l: "Price: high to low" },
];

function toQuery(p: ShopParams) {
  const sp = new URLSearchParams();
  if (p.collection.length) sp.set("collection", p.collection.join(","));
  if (p.format.length) sp.set("format", p.format.join(","));
  if (p.level.length) sp.set("level", p.level.join(","));
  if (p.max != null) sp.set("max", String(p.max));
  if (p.rating != null) sp.set("rating", String(p.rating));
  if (p.tag) sp.set("tag", p.tag);
  if (p.q) sp.set("q", p.q);
  if (p.sort && p.sort !== "popular") sp.set("sort", p.sort);
  const s = sp.toString();
  return s ? `?${s}` : "";
}

export function ShopControls({
  params,
  collections,
  hideCollection = false,
  total,
  children,
}: {
  params: ShopParams;
  collections: { slug: string; name: string; productCount: number }[];
  hideCollection?: boolean;
  total: number;
  children: ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [pending, start] = useTransition();
  const [drawer, setDrawer] = useState(false);
  const [maxDraft, setMaxDraft] = useState<number>(params.max ?? 40);

  const update = (patch: Partial<ShopParams>) => {
    const next = { ...params, ...patch };
    if ("max" in patch && patch.max == null) setMaxDraft(40);
    start(() => router.push(`${pathname}${toQuery(next)}`, { scroll: false }));
  };
  const toggle = (key: "collection" | "format" | "level", v: string) => {
    const list = params[key];
    update({ [key]: list.includes(v) ? list.filter((x) => x !== v) : [...list, v] } as Partial<ShopParams>);
  };

  const activeChips: { label: string; clear: () => void }[] = [
    ...(hideCollection
      ? []
      : params.collection.map((c) => ({
          label: collections.find((x) => x.slug === c)?.name ?? c,
          clear: () => toggle("collection", c),
        }))),
    ...params.format.map((f) => ({ label: f, clear: () => toggle("format", f) })),
    ...params.level.map((l) => ({ label: l, clear: () => toggle("level", l) })),
    ...(params.max != null ? [{ label: `Under $${params.max}`, clear: () => update({ max: null }) }] : []),
    ...(params.rating != null ? [{ label: `${params.rating}★ & up`, clear: () => update({ rating: null }) }] : []),
    ...(params.tag ? [{ label: TAGS.find((t) => t.v === params.tag)?.l ?? params.tag, clear: () => update({ tag: null }) }] : []),
    ...(params.q ? [{ label: `“${params.q}”`, clear: () => update({ q: null }) }] : []),
  ];

  const clearAll = () =>
    update({
      collection: hideCollection ? params.collection : [],
      format: [],
      level: [],
      max: null,
      rating: null,
      tag: null,
      q: null,
    });

  const Check = ({ checked, label, count, onChange }: { checked: boolean; label: string; count?: number; onChange: () => void }) => (
    <label className="group flex cursor-pointer items-center gap-3 py-1.5 text-sm">
      <input type="checkbox" checked={checked} onChange={onChange} className="peer sr-only" />
      <span className="grid h-[18px] w-[18px] place-items-center rounded-[5px] border border-ink/30 transition-colors peer-checked:border-ink peer-checked:bg-ink peer-focus-visible:ring-2 peer-focus-visible:ring-clay">
        {checked && (
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#fbf8f2" strokeWidth="3.5">
            <path d="M5 12l5 5L20 7" />
          </svg>
        )}
      </span>
      <span className="flex-1 transition-colors group-hover:text-clay">{label}</span>
      {count != null && <span className="text-xs text-muted">{count}</span>}
    </label>
  );

  const filters = (
    <div className="space-y-8">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted">Shop by</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {TAGS.map((t) => (
            <button
              key={t.v}
              onClick={() => update({ tag: params.tag === t.v ? null : t.v })}
              className={`rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all ${
                params.tag === t.v ? "border-ink bg-ink text-paper" : "border-ink/20 hover:border-ink"
              }`}
            >
              {t.l}
            </button>
          ))}
        </div>
      </div>
      {!hideCollection && (
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted">Collection</p>
          <div className="mt-2">
            {collections.map((c) => (
              <Check
                key={c.slug}
                label={c.name}
                count={c.productCount}
                checked={params.collection.includes(c.slug)}
                onChange={() => toggle("collection", c.slug)}
              />
            ))}
          </div>
        </div>
      )}
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted">Format</p>
        <div className="mt-2">
          {FORMATS.map((f) => (
            <Check key={f} label={f} checked={params.format.includes(f)} onChange={() => toggle("format", f)} />
          ))}
        </div>
      </div>
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted">Level</p>
        <div className="mt-2">
          {LEVELS.map((l) => (
            <Check key={l} label={l} checked={params.level.includes(l)} onChange={() => toggle("level", l)} />
          ))}
        </div>
      </div>
      <div>
        <div className="flex items-center justify-between">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted">Max price</p>
          <p className="text-sm font-semibold">${maxDraft}</p>
        </div>
        <input
          type="range"
          min={10}
          max={40}
          step={1}
          value={maxDraft}
          onChange={(e) => setMaxDraft(Number(e.target.value))}
          onPointerUp={() => update({ max: maxDraft >= 40 ? null : maxDraft })}
          onKeyUp={() => update({ max: maxDraft >= 40 ? null : maxDraft })}
          className="mt-3 w-full"
          aria-label="Maximum price"
        />
        <div className="mt-1 flex justify-between text-xs text-muted">
          <span>$10</span>
          <span>$40+</span>
        </div>
      </div>
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-muted">Rating</p>
        <div className="mt-3 flex gap-2">
          {[4.5, 4.8].map((r) => (
            <button
              key={r}
              onClick={() => update({ rating: params.rating === r ? null : r })}
              className={`rounded-full border px-3.5 py-1.5 text-xs font-medium transition-all ${
                params.rating === r ? "border-ink bg-ink text-paper" : "border-ink/20 hover:border-ink"
              }`}
            >
              {r}★ &amp; up
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="grid gap-10 lg:grid-cols-[240px_1fr]">
      <aside className="hidden lg:block">
        <div className="sticky top-28">{filters}</div>
      </aside>

      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-ink/10 pb-5">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setDrawer(true)}
              className="flex items-center gap-2 rounded-full border border-ink/20 px-4 py-2 text-sm font-medium lg:hidden"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M4 6h16M7 12h10M10 18h4" />
              </svg>
              Filters{activeChips.length ? ` (${activeChips.length})` : ""}
            </button>
            <p className="text-sm text-muted">
              <strong className="text-ink">{total}</strong> {total === 1 ? "guide" : "guides"}
            </p>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <span className="hidden text-muted sm:inline">Sort by</span>
            <select
              value={params.sort}
              onChange={(e) => update({ sort: e.target.value })}
              className="cursor-pointer rounded-full border border-ink/20 bg-paper px-4 py-2 text-sm font-medium outline-none focus:border-ink"
            >
              {SORTS.map((s) => (
                <option key={s.v} value={s.v}>
                  {s.l}
                </option>
              ))}
            </select>
          </label>
        </div>

        {activeChips.length > 0 && (
          <div className="mt-5 flex flex-wrap items-center gap-2">
            {activeChips.map((c) => (
              <button
                key={c.label}
                onClick={c.clear}
                className="group flex animate-fade-in items-center gap-1.5 rounded-full bg-sand px-3.5 py-1.5 text-xs font-medium hover:bg-blush"
              >
                {c.label}
                <span className="text-muted group-hover:text-ink">✕</span>
              </button>
            ))}
            <button onClick={clearAll} className="ml-1 text-xs font-semibold underline underline-offset-4 hover:text-clay">
              Clear all
            </button>
          </div>
        )}

        <div className={`mt-8 transition-opacity duration-300 ${pending ? "pointer-events-none opacity-40" : ""}`}>
          {children}
          {total === 0 && (
            <div className="rounded-[28px] bg-paper px-6 py-20 text-center">
              <p className="font-serif text-3xl">No guides match… yet.</p>
              <p className="mt-2 text-muted">Try removing a filter or two.</p>
              <button onClick={clearAll} className="mt-6 rounded-full bg-ink px-6 py-3 text-sm font-semibold text-paper">
                Clear filters
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile drawer */}
      <div className={`fixed inset-0 z-50 lg:hidden ${drawer ? "" : "pointer-events-none"}`}>
        <div
          onClick={() => setDrawer(false)}
          className={`absolute inset-0 bg-ink/40 transition-opacity duration-500 ${drawer ? "opacity-100" : "opacity-0"}`}
        />
        <div
          className={`absolute left-0 top-0 flex h-full w-[86%] max-w-sm flex-col bg-paper transition-transform duration-500 ease-[cubic-bezier(.22,1,.36,1)] ${
            drawer ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="flex items-center justify-between border-b border-ink/10 px-6 py-5">
            <p className="font-serif text-2xl">Filters</p>
            <button onClick={() => setDrawer(false)} className="rounded-full p-2 hover:bg-sand" aria-label="Close filters">
              ✕
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-6 py-6">{filters}</div>
          <div className="flex gap-3 border-t border-ink/10 p-4">
            <button onClick={clearAll} className="flex-1 rounded-full border border-ink/20 py-3 text-sm font-semibold">
              Clear
            </button>
            <button onClick={() => setDrawer(false)} className="flex-1 rounded-full bg-ink py-3 text-sm font-semibold text-paper">
              Show {total} results
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
