import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCollection, getProduct, getRelated, getReviews } from "@/lib/data";
import { Gallery } from "@/components/product/Gallery";
import { ProductCard } from "@/components/product/ProductCard";
import { ReviewForm } from "@/components/product/ReviewForm";
import { StickyBuyBar } from "@/components/product/StickyBuyBar";
import { AddToCartPanel } from "@/components/cart/AddToCartButton";
import { Stars } from "@/components/ui/Stars";
import { Reveal } from "@/components/ui/Reveal";
import { formatPrice } from "@/lib/pricing";
import { toCartItem } from "@/lib/cart-item";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: PageProps<"/products/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const p = await getProduct(slug);
  if (!p) return { title: "Guide not found" };
  return { title: `${p.title} — ${p.subtitle}`, description: p.description.slice(0, 160) };
}

const timeAgo = (d: Date) => {
  const days = Math.floor((Date.now() - new Date(d).getTime()) / 86_400_000);
  if (days < 1) return "Today";
  if (days < 7) return `${days} day${days > 1 ? "s" : ""} ago`;
  if (days < 30) return `${Math.floor(days / 7)} week${days >= 14 ? "s" : ""} ago`;
  if (days < 365) return `${Math.floor(days / 30)} month${days >= 60 ? "s" : ""} ago`;
  return `${Math.floor(days / 365)} year${days >= 730 ? "s" : ""} ago`;
};

export default async function ProductPage({ params }: PageProps<"/products/[slug]">) {
  const { slug } = await params;
  const p = await getProduct(slug);
  if (!p) notFound();

  const [collection, reviews, related] = await Promise.all([getCollection(p.collectionSlug), getReviews(p.id), getRelated(p)]);
  const item = toCartItem(p);
  const off = p.compareAtCents ? Math.round((1 - p.priceCents / p.compareAtCents) * 100) : 0;
  const dist = [5, 4, 3, 2, 1].map((n) => ({ n, c: reviews.filter((r) => r.rating === n).length }));
  const images = [
    { src: collection?.image ?? "/images/hero.jpg", alt: `${collection?.name ?? "Zikkytalk"} lifestyle` },
    { src: p.id % 2 ? "/images/lifestyle-reading.jpg" : "/images/lifestyle-desk.jpg", alt: "Reading on a tablet" },
  ];

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: p.title,
    description: p.description,
    brand: { "@type": "Brand", name: "Zikkytalk" },
    offers: { "@type": "Offer", price: (p.priceCents / 100).toFixed(2), priceCurrency: "USD", availability: "https://schema.org/InStock" },
    aggregateRating: p.reviewCount ? { "@type": "AggregateRating", ratingValue: p.rating, reviewCount: p.reviewCount } : undefined,
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="mx-auto max-w-7xl px-4 pt-8 sm:px-6 lg:px-8">
        <nav className="text-xs text-muted">
          <Link href="/" className="hover:text-ink">
            Home
          </Link>{" "}
          /{" "}
          <Link href={`/collections/${p.collectionSlug}`} className="hover:text-ink">
            {collection?.name}
          </Link>{" "}
          / <span className="text-ink">{p.title}</span>
        </nav>

        <div className="mt-6 grid gap-10 lg:grid-cols-2 lg:gap-16">
          <div className="animate-fade-in">
            <Gallery
              title={p.title}
              subtitle={p.subtitle}
              author={p.author}
              cover={p.cover}
              toc={p.toc}
              highlights={p.highlights}
              images={images}
            />
          </div>

          <div className="animate-fade-up">
            <div className="flex flex-wrap items-center gap-2">
              <Link
                href={`/collections/${p.collectionSlug}`}
                className="rounded-full px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-paper"
                style={{ background: collection?.accent ?? "#1c1714" }}
              >
                {collection?.name}
              </Link>
              {p.bestseller && (
                <span className="rounded-full bg-ink px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-paper">
                  Bestseller
                </span>
              )}
              {p.isNew && (
                <span className="rounded-full border border-ink/20 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em]">
                  New
                </span>
              )}
            </div>
            <h1 className="mt-5 font-serif text-5xl leading-[0.95] tracking-tight sm:text-6xl">{p.title}</h1>
            <p className="mt-3 font-serif text-xl italic text-ink-soft">{p.subtitle}</p>
            <a href="#reviews" className="mt-5 inline-flex items-center gap-2 text-sm">
              <Stars rating={p.rating} size={16} />
              <strong>{p.rating.toFixed(1)}</strong>
              <span className="text-muted underline underline-offset-4">{p.reviewCount} reviews</span>
              <span className="text-ink/20">•</span>
              <span className="text-muted">{p.salesCount.toLocaleString()} downloads</span>
            </a>

            <div className="mt-7 flex items-end gap-3">
              <p className="font-serif text-4xl">{formatPrice(p.priceCents)}</p>
              {p.compareAtCents && (
                <>
                  <p className="pb-1 text-lg text-muted line-through">{formatPrice(p.compareAtCents)}</p>
                  <span className="mb-1.5 rounded-full bg-clay/10 px-2.5 py-0.5 text-xs font-semibold text-clay">Save {off}%</span>
                </>
              )}
            </div>
            <p className="mt-1 text-xs text-muted">One-time purchase · Lifetime access · Free updates</p>

            <p className="mt-7 leading-relaxed text-ink-soft">{p.description}</p>

            <ul className="mt-7 space-y-2.5">
              {p.highlights.map((h) => (
                <li key={h} className="flex gap-3 text-sm">
                  <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-sage/15 text-sage">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <path d="M5 12l5 5L20 7" />
                    </svg>
                  </span>
                  {h}
                </li>
              ))}
            </ul>

            <div id="buy-panel" className="mt-8">
              <AddToCartPanel item={item} />
            </div>
            <p className="mt-3 rounded-2xl bg-sand/70 px-4 py-3 text-center text-xs">
              ✦ Add 2 guides & save <strong>10%</strong> · 3+ guides & save <strong>20%</strong>
            </p>

            <dl className="mt-8 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-ink/10 bg-ink/10 text-sm sm:grid-cols-4">
              {[
                { k: "Pages", v: String(p.pages) },
                { k: "Format", v: p.format },
                { k: "Level", v: p.level },
                { k: "File", v: "PDF" },
              ].map((s) => (
                <div key={s.k} className="bg-paper px-4 py-3">
                  <dt className="text-[11px] uppercase tracking-[0.15em] text-muted">{s.k}</dt>
                  <dd className="mt-0.5 font-medium">{s.v}</dd>
                </div>
              ))}
            </dl>

            <div className="mt-8 divide-y divide-ink/10 border-y border-ink/10">
              <details className="group py-5" open>
                <summary className="flex cursor-pointer list-none items-center justify-between font-serif text-xl">
                  What&apos;s inside
                  <span className="transition-transform group-open:rotate-45">+</span>
                </summary>
                <ol className="mt-4 space-y-3">
                  {p.toc.map((c, i) => (
                    <li key={c.title} className="flex items-baseline gap-4 text-sm">
                      <span className="font-serif text-clay">{String(i + 1).padStart(2, "0")}</span>
                      <span className="flex-1">{c.title}</span>
                      <span className="text-xs text-muted">pp. {c.pages}</span>
                    </li>
                  ))}
                </ol>
              </details>
              <details className="group py-5">
                <summary className="flex cursor-pointer list-none items-center justify-between font-serif text-xl">
                  Delivery &amp; devices
                  <span className="transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-4 text-sm leading-relaxed text-ink-soft">
                  Instant download after checkout, plus a copy sent to your email. Optimised for phones, tablets and
                  laptops. Journals and planners are hyperlinked for GoodNotes, Notability and Xodo. Print-ready on A4
                  and US Letter.
                </p>
              </details>
              <details className="group py-5">
                <summary className="flex cursor-pointer list-none items-center justify-between font-serif text-xl">
                  Written by {p.author}
                  <span className="transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-4 text-sm leading-relaxed text-ink-soft">
                  Zikky is the voice behind Zikkytalk — a community of 200k+ twenty-somethings swapping real talk about
                  money, careers and life. Every guide is researched, tested with readers and reviewed by subject
                  experts before release.
                </p>
              </details>
            </div>

            <div className="mt-6 grid grid-cols-3 gap-3 text-center text-[11px] text-muted">
              {[
                ["⚡", "Instant download"],
                ["🔒", "Secure checkout"],
                ["↺", "14-day guarantee"],
              ].map(([i, t]) => (
                <div key={t} className="rounded-2xl bg-paper px-2 py-3">
                  <p className="text-lg">{i}</p>
                  <p className="mt-1">{t}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* REVIEWS */}
        <section id="reviews" className="mt-28 scroll-mt-28">
          <Reveal className="grid gap-12 lg:grid-cols-[340px_1fr]">
            <div className="lg:sticky lg:top-28 lg:self-start">
              <p className="text-xs font-semibold uppercase tracking-[0.25em] text-clay">Reviews</p>
              <h2 className="mt-3 font-serif text-4xl">What readers say</h2>
              <div className="mt-6 flex items-center gap-4">
                <p className="font-serif text-6xl">{p.rating.toFixed(1)}</p>
                <div>
                  <Stars rating={p.rating} size={18} />
                  <p className="mt-1 text-sm text-muted">Based on {p.reviewCount} reviews</p>
                </div>
              </div>
              <div className="mt-6 space-y-2">
                {dist.map((d) => (
                  <div key={d.n} className="flex items-center gap-3 text-sm">
                    <span className="w-6 text-muted">{d.n}★</span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-ink/10">
                      <div
                        className="h-full rounded-full bg-clay"
                        style={{ width: `${reviews.length ? (d.c / reviews.length) * 100 : 0}%` }}
                      />
                    </div>
                    <span className="w-6 text-right text-muted">{d.c}</span>
                  </div>
                ))}
              </div>
              <div className="mt-8">
                <ReviewForm productId={p.id} />
              </div>
            </div>

            <div className="divide-y divide-ink/10">
              {reviews.length === 0 && <p className="py-8 text-muted">No reviews yet — be the first!</p>}
              {reviews.map((r) => (
                <article key={r.id} className="py-8 first:pt-0">
                  <div className="flex items-center justify-between gap-4">
                    <Stars rating={r.rating} />
                    <span className="text-xs text-muted">{timeAgo(r.createdAt)}</span>
                  </div>
                  <h3 className="mt-3 font-serif text-2xl">{r.title}</h3>
                  <p className="mt-2 max-w-2xl leading-relaxed text-ink-soft">{r.body}</p>
                  <div className="mt-4 flex flex-wrap items-center gap-3 text-xs">
                    <span className="grid h-8 w-8 place-items-center rounded-full bg-sand font-semibold">
                      {r.author.charAt(0)}
                    </span>
                    <span className="font-semibold">{r.author}</span>
                    {r.age && <span className="text-muted">Age {r.age}</span>}
                    {r.location && <span className="text-muted">· {r.location}</span>}
                    {r.verified && (
                      <span className="rounded-full bg-sage/15 px-2 py-0.5 font-medium text-sage">✓ Verified buyer</span>
                    )}
                  </div>
                </article>
              ))}
            </div>
          </Reveal>
        </section>

        {/* RELATED */}
        <section className="mt-28">
          <Reveal className="flex items-end justify-between">
            <h2 className="font-serif text-4xl">Pairs well with</h2>
            <Link href={`/collections/${p.collectionSlug}`} className="text-sm font-semibold underline underline-offset-4">
              More from {collection?.name}
            </Link>
          </Reveal>
          <div className="mt-10 grid grid-cols-1 gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((r, i) => (
              <Reveal key={r.id} delay={i * 80}>
                <ProductCard product={r} />
              </Reveal>
            ))}
          </div>
        </section>
      </div>
      <StickyBuyBar item={item} anchorId="buy-panel" />
    </>
  );
}
