import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ShopView, parseShopParams } from "@/components/shop/ShopView";
import { getCollection } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: PageProps<"/collections/[slug]">): Promise<Metadata> {
  const { slug } = await params;
  const c = await getCollection(slug);
  return c ? { title: c.name, description: c.description } : { title: "Collection not found" };
}

export default async function CollectionPage({ params, searchParams }: PageProps<"/collections/[slug]">) {
  const { slug } = await params;
  const c = await getCollection(slug);
  if (!c) notFound();
  const shopParams = parseShopParams(await searchParams, slug);

  return (
    <>
      <section className="mx-auto max-w-7xl px-4 pt-6 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-[36px] text-paper">
          <Image src={c.image} alt={c.name} fill priority sizes="100vw" className="object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-ink/85 via-ink/50 to-ink/10" />
          <div className="relative px-6 py-20 sm:px-12 lg:py-28">
            <nav className="text-xs text-paper/70">
              <Link href="/" className="hover:text-paper">
                Home
              </Link>{" "}
              /{" "}
              <Link href="/shop" className="hover:text-paper">
                Shop
              </Link>{" "}
              / <span className="text-paper">{c.name}</span>
            </nav>
            <p className="mt-8 text-xs font-semibold uppercase tracking-[0.25em]" style={{ color: "#F3D9CC" }}>
              Collection
            </p>
            <h1 className="animate-fade-up mt-3 font-serif text-5xl tracking-tight sm:text-7xl">{c.name}</h1>
            <p className="animate-fade-up mt-3 font-serif text-2xl italic text-paper/90" style={{ animationDelay: "80ms" }}>
              {c.tagline}
            </p>
            <p className="animate-fade-up mt-4 max-w-lg text-paper/75" style={{ animationDelay: "160ms" }}>
              {c.description}
            </p>
          </div>
        </div>
      </section>
      <div className="mx-auto max-w-7xl px-4 pt-14 sm:px-6 lg:px-8">
        <ShopView params={shopParams} hideCollection />
      </div>
    </>
  );
}
