import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Fraunces, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/components/cart/CartProvider";
import { CartDrawer } from "@/components/cart/CartDrawer";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { siteUrl } from "@/lib/site";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
  axes: ["SOFT", "opsz"],
});
const jakarta = Plus_Jakarta_Sans({ subsets: ["latin"], variable: "--font-jakarta", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Zikkytalk — Digital guides for your twenties",
    template: "%s · Zikkytalk",
  },
  description:
    "Beautifully designed PDF guides, workbooks and planners on money, career, mindset, love and side hustles — made for 19 to 29 year olds. Instant download.",
  openGraph: {
    title: "Zikkytalk — Digital guides for your twenties",
    description: "Premium PDF guides on money, career, wellness, love and side hustles. Instant download.",
    images: ["/images/hero.jpg"],
  },
};

export const viewport: Viewport = { themeColor: "#f6f0e6" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${jakarta.variable}`}>
      <body className="min-h-screen bg-cream text-ink antialiased">
        <CartProvider>
          <Header />
          <main className="min-h-[60vh]">{children}</main>
          <Footer />
          <CartDrawer />
        </CartProvider>
      </body>
    </html>
  );
}
