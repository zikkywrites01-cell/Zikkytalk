import type { Metadata } from "next";
import Link from "next/link";
import { ShopView, parseShopParams } from "@/components/shop/ShopView";
import { getCollections } from "@/lib/data";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Shop all guides",
  description: "Browse every Zikkytalk PDF guide, workbook, journal and planner.",
};

const TITLES: Record<string, { t: string; d: string }> = {
  bestseller: { t: "Bestsellers", d: "The guides our readers can't stop recommending." },
  new: { t: "New in", d: "Fresh drops, hot off the (digital) press." },
  sale: { t: "On sale", d: "Premium guides, friendlier prices — for a limited time." },
};

export default async function ShopPage({ searchParams }: PageProps<"/shop">) {
  const sp = await searchParams;
  const params = parseShopParams(sp);
  const collections = await getCollections();
  const heading = params.tag ? TITLES[params.tag] : null;

  return (
    <div className="mx-auto max-w-7xl px-4 pb-10 pt-10 sm:px-6 lg:px-8 lg:pt-14">
      <nav className="text-xs text-muted">
        <Link href="/" className="hover:text-ink">
          Home
        </Link>{" "}
        / <span className="text-ink">Shop</span>
      </nav>
      <div className="mt-4 flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
        <div>
          <h1 className="animate-fade-up font-serif text-5xl tracking-tight sm:text-6xl">
            {params.q ? (
              <>
                Results for <em className="text-clay">&ldquo;{params.q}&rdquo;</em>
              </>
            ) : (
              heading?.t ?? (
                <>
                  All <em className="text-clay">guides</em>
                </>
              )
            )}
          </h1>
          <p className="mt-3 max-w-xl text-muted">
            {heading?.d ?? "Beautifully designed PDFs for money, career, mindset, love and side hustles. Instant download."}
          </p>
        </div>
        <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 lg:mx-0 lg:px-0">
          {collections.map((c) => (
            <Link
              key={c.slug}
              href={`/collections/${c.slug}`}
              className="flex shrink-0 items-center gap-2 rounded-full border border-ink/15 bg-paper py-1.5 pl-1.5 pr-4 text-sm transition-colors hover:border-ink"
            >
              <span className="h-6 w-6 rounded-full bg-cover bg-center" style={{ backgroundImage: `url(${c.image})` }} />
              {c.name}
            </Link>
          ))}
        </div>
      </div>
      <div className="mt-10">
        <ShopView params={params} />
      </div>
    </div>
  );
}
