"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent, type ReactNode } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { BookCover } from "@/components/product/BookCover";
import { PROMO_CODES, computeTotals, formatPrice } from "@/lib/pricing";

const COUNTRIES = [
  "United States",
  "United Kingdom",
  "Nigeria",
  "Canada",
  "Ghana",
  "Kenya",
  "South Africa",
  "Ireland",
  "Australia",
  "Germany",
  "France",
  "United Arab Emirates",
  "Other",
];

const fmtCard = (v: string) =>
  v
    .replace(/\D/g, "")
    .slice(0, 16)
    .replace(/(.{4})/g, "$1 ")
    .trim();
const fmtExp = (v: string) => {
  const d = v.replace(/\D/g, "").slice(0, 4);
  return d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
};

function Field({ label, error, children }: { label: string; error?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-muted">{label}</span>
      <div className="mt-1.5">{children}</div>
      {error && <span className="mt-1 block animate-fade-in text-xs text-clay">{error}</span>}
    </label>
  );
}

const inputCls = (err?: string) =>
  `w-full rounded-xl border bg-paper px-4 py-3.5 text-sm outline-none transition placeholder:text-muted/60 focus:border-ink focus:ring-4 focus:ring-ink/5 ${
    err ? "border-clay" : "border-ink/15"
  }`;

export function CheckoutClient() {
  const { items, promo, setPromo, remove, clear, hydrated } = useCart();
  const router = useRouter();
  const [form, setForm] = useState({
    email: "",
    name: "",
    country: "United States",
    gift: false,
    card: "",
    exp: "",
    cvc: "",
    cardName: "",
  });
  const [method, setMethod] = useState<"card" | "wallet">("card");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [promoDraft, setPromoDraft] = useState("");
  const [promoMsg, setPromoMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [status, setStatus] = useState<"idle" | "paying" | "redirecting">("idle");
  const [serverError, setServerError] = useState("");
  const [showSummary, setShowSummary] = useState(false);

  const t = computeTotals(
    items.map((i) => i.priceCents),
    promo,
  );
  const set = (k: keyof typeof form, v: string | boolean) => setForm((f) => ({ ...f, [k]: v }));

  const applyPromo = () => {
    const code = promoDraft.trim().toUpperCase();
    if (!code) return;
    if (PROMO_CODES[code]) {
      setPromo(code);
      setPromoMsg({ ok: true, text: PROMO_CODES[code].label });
      setPromoDraft("");
    } else setPromoMsg({ ok: false, text: "That code isn't valid. Try ZIKKY10." });
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = "Enter a valid email so we can send your downloads.";
    if (form.name.trim().length < 2) e.name = "Enter your name.";
    if (method === "card") {
      if (form.card.replace(/\s/g, "").length !== 16) e.card = "Card number should be 16 digits.";
      const [mm, yy] = form.exp.split("/").map(Number);
      const now = new Date();
      const expDate = new Date(2000 + (yy || 0), mm || 0, 0);
      if (!mm || mm > 12 || !yy || expDate < now) e.exp = "Invalid or expired date.";
      if (!/^\d{3,4}$/.test(form.cvc)) e.cvc = "3–4 digits.";
      if (form.cardName.trim().length < 2) e.cardName = "Name on card.";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setServerError("");
    if (!validate()) return;
    setStatus("paying");
    try {
      const [res] = await Promise.all([
        fetch("/api/orders", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: form.email,
            name: form.name,
            country: form.country,
            promo,
            items: items.map((i) => i.slug),
          }),
        }),
        new Promise((r) => setTimeout(r, 1100)),
      ]);
      const json = (await res.json()) as { orderId?: string; error?: string };
      if (!res.ok || !json.orderId) throw new Error(json.error ?? "Payment failed. Please try again.");
      setStatus("redirecting");
      router.push(`/checkout/success?order=${json.orderId}`);
      setTimeout(clear, 300);
    } catch (err) {
      setServerError(err instanceof Error ? err.message : "Something went wrong.");
      setStatus("idle");
    }
  };

  if (!hydrated || status === "redirecting") {
    return (
      <div className="grid min-h-[60vh] place-items-center">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-ink/15 border-t-clay" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-lg px-4 py-28 text-center">
        <p className="font-serif text-5xl">Your bag is empty</p>
        <p className="mt-3 text-muted">Find a guide you love and come back — checkout takes under a minute.</p>
        <Link href="/shop" className="mt-8 inline-block rounded-full bg-ink px-7 py-4 text-sm font-semibold text-paper hover:bg-clay">
          Browse guides
        </Link>
      </div>
    );
  }

  const summary = (
    <div className="rounded-[28px] bg-paper p-6 sm:p-8">
      <ul className="divide-y divide-ink/10">
        {items.map((i) => (
          <li key={i.slug} className="flex gap-4 py-4 first:pt-0">
            <div className="w-14 shrink-0">
              <BookCover title={i.title} cover={i.cover} shadow={false} className="shadow" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-serif text-lg leading-tight">{i.title}</p>
              <p className="mt-0.5 text-xs text-muted">
                {i.format} · {i.pages} pages
              </p>
              <button onClick={() => remove(i.slug)} className="mt-1 text-xs text-muted underline-offset-4 hover:text-clay hover:underline">
                Remove
              </button>
            </div>
            <p className="text-sm font-medium">{formatPrice(i.priceCents)}</p>
          </li>
        ))}
      </ul>

      <div className="mt-4 border-t border-ink/10 pt-5">
        {promo ? (
          <div className="flex items-center justify-between rounded-xl bg-sage/10 px-4 py-3 text-sm">
            <span>
              <strong className="text-sage">{promo}</strong> applied
            </span>
            <button
              onClick={() => {
                setPromo("");
                setPromoMsg(null);
              }}
              className="text-xs text-muted hover:text-clay"
            >
              Remove
            </button>
          </div>
        ) : (
          <div className="flex gap-2">
            <input
              value={promoDraft}
              onChange={(e) => setPromoDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  applyPromo();
                }
              }}
              placeholder="Promo code"
              className={`${inputCls()} py-3 uppercase`}
            />
            <button
              type="button"
              onClick={applyPromo}
              className="rounded-xl border border-ink px-5 text-sm font-semibold transition-colors hover:bg-ink hover:text-paper"
            >
              Apply
            </button>
          </div>
        )}
        {promoMsg && <p className={`mt-2 text-xs ${promoMsg.ok ? "text-sage" : "text-clay"}`}>{promoMsg.text}</p>}
      </div>

      <dl className="mt-5 space-y-2.5 border-t border-ink/10 pt-5 text-sm">
        <div className="flex justify-between">
          <dt className="text-muted">Subtotal</dt>
          <dd>{formatPrice(t.subtotal)}</dd>
        </div>
        {t.bundleDiscount > 0 && (
          <div className="flex justify-between text-sage">
            <dt>Bundle savings ({t.bundlePercent}%)</dt>
            <dd>−{formatPrice(t.bundleDiscount)}</dd>
          </div>
        )}
        {t.promoDiscount > 0 && (
          <div className="flex justify-between text-sage">
            <dt>Promo ({promo})</dt>
            <dd>−{formatPrice(t.promoDiscount)}</dd>
          </div>
        )}
        <div className="flex justify-between">
          <dt className="text-muted">Delivery</dt>
          <dd>Instant · Free</dd>
        </div>
        <div className="flex items-baseline justify-between border-t border-ink/10 pt-4">
          <dt className="font-serif text-xl">Total</dt>
          <dd className="font-serif text-3xl">{formatPrice(t.total)}</dd>
        </div>
        {t.discount > 0 && <p className="text-right text-xs text-sage">You&apos;re saving {formatPrice(t.discount)} 🎉</p>}
      </dl>
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-4 pb-10 pt-8 sm:px-6 lg:px-8 lg:pt-12">
      <ol className="flex items-center gap-3 text-xs font-medium">
        {["Bag", "Details & payment", "Download"].map((s, i) => (
          <li key={s} className="flex items-center gap-3">
            <span
              className={`grid h-6 w-6 place-items-center rounded-full text-[11px] ${
                i === 0 ? "bg-sage text-paper" : i === 1 ? "bg-ink text-paper" : "bg-ink/10 text-muted"
              }`}
            >
              {i === 0 ? "✓" : i + 1}
            </span>
            <span className={i === 2 ? "text-muted" : ""}>{s}</span>
            {i < 2 && <span className="h-px w-6 bg-ink/20 sm:w-12" />}
          </li>
        ))}
      </ol>
      <h1 className="mt-6 font-serif text-5xl tracking-tight">Checkout</h1>

      {/* mobile summary toggle */}
      <button
        onClick={() => setShowSummary((s) => !s)}
        className="mt-6 flex w-full items-center justify-between rounded-2xl bg-paper px-5 py-4 text-sm lg:hidden"
      >
        <span className="font-medium">
          {showSummary ? "Hide" : "Show"} order summary ({items.length})
        </span>
        <span className="font-serif text-xl">{formatPrice(t.total)}</span>
      </button>
      <div className={`overflow-hidden transition-all duration-500 lg:hidden ${showSummary ? "mt-4 max-h-[1400px]" : "max-h-0"}`}>
        {summary}
      </div>

      <div className="mt-8 grid gap-10 lg:grid-cols-[1.2fr_1fr] lg:gap-16">
        <form onSubmit={submit} noValidate className="space-y-10">
          <section>
            <h2 className="flex items-center gap-3 font-serif text-2xl">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-ink font-sans text-xs text-paper">1</span>
              Where should we send it?
            </h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Field label={form.gift ? "Recipient's email" : "Email for downloads"} error={errors.email}>
                  <input
                    type="email"
                    autoComplete="email"
                    value={form.email}
                    onChange={(e) => set("email", e.target.value)}
                    placeholder="you@email.com"
                    className={inputCls(errors.email)}
                  />
                </Field>
              </div>
              <Field label="Full name" error={errors.name}>
                <input
                  autoComplete="name"
                  value={form.name}
                  onChange={(e) => set("name", e.target.value)}
                  placeholder="Ada Lovelace"
                  className={inputCls(errors.name)}
                />
              </Field>
              <Field label="Country">
                <select value={form.country} onChange={(e) => set("country", e.target.value)} className={inputCls()}>
                  {COUNTRIES.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </Field>
              <label className="flex cursor-pointer items-center gap-3 text-sm sm:col-span-2">
                <input
                  type="checkbox"
                  checked={form.gift}
                  onChange={(e) => set("gift", e.target.checked)}
                  className="h-4 w-4 accent-[#b4532a]"
                />
                🎁 This is a gift — send the downloads to someone else
              </label>
            </div>
          </section>

          <section>
            <h2 className="flex items-center gap-3 font-serif text-2xl">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-ink font-sans text-xs text-paper">2</span>
              Payment
            </h2>
            <p className="mt-2 rounded-xl bg-sand/70 px-4 py-2.5 text-xs text-ink-soft">
              Demo store — no real charge is made. Use any test card, e.g. <strong>4242 4242 4242 4242</strong>, any future
              date and any CVC.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-3">
              {(
                [
                  ["card", "💳 Card"],
                  ["wallet", "📱 Apple Pay / G Pay"],
                ] as const
              ).map(([m, l]) => (
                <button
                  type="button"
                  key={m}
                  onClick={() => setMethod(m)}
                  className={`rounded-xl border px-4 py-3.5 text-sm font-medium transition-all ${
                    method === m ? "border-ink bg-paper ring-4 ring-ink/5" : "border-ink/15 hover:border-ink/40"
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>

            {method === "card" ? (
              <div className="mt-5 grid animate-fade-in grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Field label="Card number" error={errors.card}>
                    <div className="relative">
                      <input
                        inputMode="numeric"
                        autoComplete="cc-number"
                        value={form.card}
                        onChange={(e) => set("card", fmtCard(e.target.value))}
                        placeholder="1234 5678 9012 3456"
                        className={`${inputCls(errors.card)} pr-16 tracking-wider`}
                      />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] font-bold tracking-widest text-muted">
                        {form.card.startsWith("4") ? "VISA" : form.card.startsWith("5") ? "MC" : "CARD"}
                      </span>
                    </div>
                  </Field>
                </div>
                <Field label="Expiry (MM/YY)" error={errors.exp}>
                  <input
                    inputMode="numeric"
                    autoComplete="cc-exp"
                    value={form.exp}
                    onChange={(e) => set("exp", fmtExp(e.target.value))}
                    placeholder="08/29"
                    className={inputCls(errors.exp)}
                  />
                </Field>
                <Field label="CVC" error={errors.cvc}>
                  <input
                    inputMode="numeric"
                    autoComplete="cc-csc"
                    value={form.cvc}
                    onChange={(e) => set("cvc", e.target.value.replace(/\D/g, "").slice(0, 4))}
                    placeholder="123"
                    className={inputCls(errors.cvc)}
                  />
                </Field>
                <div className="col-span-2">
                  <Field label="Name on card" error={errors.cardName}>
                    <input
                      autoComplete="cc-name"
                      value={form.cardName}
                      onChange={(e) => set("cardName", e.target.value)}
                      placeholder="As shown on card"
                      className={inputCls(errors.cardName)}
                    />
                  </Field>
                </div>
              </div>
            ) : (
              <p className="mt-5 animate-fade-in rounded-xl border border-ink/15 bg-paper px-4 py-5 text-sm text-ink-soft">
                You&apos;ll confirm with your wallet in one tap after clicking pay below.
              </p>
            )}
          </section>

          {serverError && <p className="rounded-xl bg-clay/10 px-4 py-3 text-sm text-clay">{serverError}</p>}

          <div>
            <button
              disabled={status === "paying"}
              className="relative flex w-full items-center justify-center gap-3 overflow-hidden rounded-full bg-ink py-5 text-base font-semibold text-paper transition-all hover:bg-clay disabled:cursor-wait disabled:opacity-80"
            >
              {status === "paying" ? (
                <>
                  <span className="h-5 w-5 animate-spin rounded-full border-2 border-paper/30 border-t-paper" />
                  Processing securely…
                </>
              ) : (
                <>🔒 Pay {formatPrice(t.total)}</>
              )}
            </button>
            <p className="mt-4 text-center text-xs text-muted">
              By paying you agree to our terms. Instant download · 14-day money-back guarantee.
            </p>
          </div>
        </form>

        <aside className="hidden lg:block">
          <div className="sticky top-28">
            <h2 className="mb-4 font-serif text-2xl">Order summary</h2>
            {summary}
            <div className="mt-6 flex items-center gap-4 rounded-2xl border border-ink/10 px-5 py-4 text-sm">
              <span className="text-2xl">⚡</span>
              <p className="text-ink-soft">
                Your guides unlock <strong>immediately</strong> after payment — plus a copy lands in your inbox.
              </p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
