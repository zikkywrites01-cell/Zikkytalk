import type { Metadata } from "next";
import Link from "next/link";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { orderItems, orders, products } from "@/db/schema";
import { BookCover } from "@/components/product/BookCover";
import { formatPrice } from "@/lib/pricing";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Thank you!", robots: { index: false } };

export default async function SuccessPage({ searchParams }: PageProps<"/checkout/success">) {
  const sp = await searchParams;
  const orderId = typeof sp.order === "string" ? sp.order : "";
  await ensureDb();
  const [order] = orderId ? await db.select().from(orders).where(eq(orders.id, orderId)) : [];

  if (!order) {
    return (
      <div className="mx-auto max-w-lg px-4 py-28 text-center">
        <p className="font-serif text-4xl">We couldn&apos;t find that order</p>
        <p className="mt-3 text-muted">Check your email for your download links, or contact hello@zikkytalk.com.</p>
        <Link href="/shop" className="mt-8 inline-block rounded-full bg-ink px-7 py-4 text-sm font-semibold text-paper">
          Back to shop
        </Link>
      </div>
    );
  }

  const lines = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  const prods = lines.length
    ? await db
        .select()
        .from(products)
        .where(
          inArray(
            products.id,
            lines.map((l) => l.productId),
          ),
        )
    : [];

  return (
    <div className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[420px] bg-gradient-to-b from-blush/70 to-transparent" />
      {Array.from({ length: 14 }).map((_, i) => (
        <span
          key={i}
          className="pointer-events-none absolute animate-float text-clay/60"
          style={{
            left: `${(i * 71) % 100}%`,
            top: `${(i * 37) % 30}%`,
            fontSize: 10 + ((i * 7) % 18),
            animationDelay: `${(i % 5) * 0.6}s`,
          }}
        >
          ✦
        </span>
      ))}
      <div className="relative mx-auto max-w-3xl px-4 pb-10 pt-16 text-center sm:px-6">
        <div className="mx-auto grid h-16 w-16 animate-pop place-items-center rounded-full bg-sage text-2xl text-paper">✓</div>
        <p className="mt-6 text-xs font-semibold uppercase tracking-[0.25em] text-clay">Order {order.id}</p>
        <h1 className="animate-fade-up mt-3 font-serif text-5xl tracking-tight sm:text-6xl">
          You&apos;re all set, {order.name.split(" ")[0]}!
        </h1>
        <p className="mx-auto mt-4 max-w-lg text-ink-soft">
          Your guides are ready to download below. We&apos;ve also emailed links to <strong>{order.email}</strong> so you can
          grab them anytime.
        </p>
      </div>

      <div className="relative mx-auto max-w-3xl px-4 sm:px-6">
        <ul className="space-y-4">
          {prods.map((p, i) => (
            <li
              key={p.id}
              className="flex animate-fade-up flex-col items-center gap-5 rounded-[28px] bg-paper p-5 sm:flex-row"
              style={{ animationDelay: `${150 + i * 100}ms` }}
            >
              <div className="w-20 shrink-0">
                <BookCover title={p.title} cover={p.cover} />
              </div>
              <div className="flex-1 text-center sm:text-left">
                <p className="font-serif text-2xl leading-tight">{p.title}</p>
                <p className="mt-1 text-sm text-muted">
                  {p.format} · {p.pages} pages · PDF
                </p>
              </div>
              <a
                href={`/api/download/${order.id}/${p.slug}`}
                className="flex items-center gap-2 rounded-full bg-ink px-6 py-3.5 text-sm font-semibold text-paper transition-colors hover:bg-clay"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 4v12M6 10l6 6 6-6M5 20h14" />
                </svg>
                Download PDF
              </a>
            </li>
          ))}
        </ul>

        <div className="mt-8 rounded-[28px] border border-ink/10 p-6 text-sm">
          <dl className="space-y-2">
            <div className="flex justify-between">
              <dt className="text-muted">Subtotal</dt>
              <dd>{formatPrice(order.subtotalCents)}</dd>
            </div>
            {order.discountCents > 0 && (
              <div className="flex justify-between text-sage">
                <dt>Savings{order.promoCode ? ` (incl. ${order.promoCode})` : ""}</dt>
                <dd>−{formatPrice(order.discountCents)}</dd>
              </div>
            )}
            <div className="flex justify-between border-t border-ink/10 pt-3 font-serif text-xl">
              <dt>Paid</dt>
              <dd>{formatPrice(order.totalCents)}</dd>
            </div>
          </dl>
        </div>

        <div className="mt-10 text-center">
          <p className="text-sm text-muted">Tip: on iPad, open the PDF and tap “Share → GoodNotes” to start writing in it.</p>
          <Link href="/shop" className="mt-6 inline-block rounded-full border border-ink px-7 py-3.5 text-sm font-semibold hover:bg-ink hover:text-paper">
            Keep browsing
          </Link>
        </div>
      </div>
    </div>
  );
}
