import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-xl px-4 py-32 text-center">
      <p className="font-serif text-[8rem] leading-none text-clay">404</p>
      <h1 className="mt-4 font-serif text-4xl">This page took a soft-life day off.</h1>
      <p className="mt-3 text-muted">The page you&apos;re looking for doesn&apos;t exist — but your next favourite guide does.</p>
      <Link href="/shop" className="mt-8 inline-block rounded-full bg-ink px-7 py-4 text-sm font-semibold text-paper hover:bg-clay">
        Browse the shop
      </Link>
    </div>
  );
}
