import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    // Bootstraps tables + demo catalogue on first boot (idempotent).
    await ensureDb().catch(() => undefined);
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
