import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { products, reviews } from "@/db/schema";

const clean = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

export async function POST(req: Request) {
  await ensureDb();
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return NextResponse.json({ error: "Invalid request" }, { status: 400 });

  const productId = Number(body.productId);
  const rating = Math.round(Number(body.rating));
  const author = clean(body.author, 40);
  const title = clean(body.title, 80);
  const text = clean(body.body, 1200);
  const location = clean(body.location, 40) || null;
  const ageNum = Number(body.age);
  const age = Number.isFinite(ageNum) && ageNum >= 13 && ageNum <= 99 ? Math.round(ageNum) : null;

  if (!Number.isInteger(productId) || rating < 1 || rating > 5)
    return NextResponse.json({ error: "Please choose a rating." }, { status: 400 });
  if (author.length < 2 || title.length < 2 || text.length < 10)
    return NextResponse.json({ error: "Please add your name, a title and at least 10 characters." }, { status: 400 });

  const [p] = await db.select({ id: products.id }).from(products).where(eq(products.id, productId));
  if (!p) return NextResponse.json({ error: "Product not found" }, { status: 404 });

  const [created] = await db
    .insert(reviews)
    .values({ productId, rating, author, title, body: text, location, age, verified: false })
    .returning();
  return NextResponse.json({ review: created }, { status: 201 });
}
