import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { orderItems, orders, products } from "@/db/schema";
import { buildGuidePdf } from "@/lib/pdf";

export async function GET(_req: Request, ctx: RouteContext<"/api/download/[orderId]/[slug]">) {
  await ensureDb();
  const { orderId, slug } = await ctx.params;

  const [order] = await db.select().from(orders).where(eq(orders.id, orderId));
  if (!order) return new Response("Order not found", { status: 404 });
  const [line] = await db
    .select()
    .from(orderItems)
    .where(and(eq(orderItems.orderId, orderId), eq(orderItems.slug, slug)));
  if (!line) return new Response("This guide isn't part of that order", { status: 403 });
  const [p] = await db.select().from(products).where(eq(products.id, line.productId));
  if (!p) return new Response("Guide not found", { status: 404 });

  const pdf = buildGuidePdf({
    title: p.title,
    subtitle: p.subtitle,
    author: p.author,
    description: p.description,
    highlights: p.highlights,
    toc: p.toc,
    cover: p.cover,
    licensee: order.name,
    orderId: order.id,
  });

  return new Response(new Uint8Array(pdf), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="zikkytalk-${p.slug}.pdf"`,
      "Cache-Control": "private, no-store",
    },
  });
}
