import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { orderItems, orders, products } from "@/db/schema";
import { computeTotals } from "@/lib/pricing";

const str = (v: unknown, max = 120) => (typeof v === "string" ? v.trim().slice(0, max) : "");

export async function POST(req: Request) {
  await ensureDb();
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return NextResponse.json({ error: "Invalid request" }, { status: 400 });

  const email = str(body.email).toLowerCase();
  const name = str(body.name, 80);
  const country = str(body.country, 60) || "Other";
  const promo = str(body.promo, 30).toUpperCase() || null;
  const slugs = Array.isArray(body.items)
    ? [...new Set(body.items.filter((s): s is string => typeof s === "string"))].slice(0, 50)
    : [];

  if (!/^\S+@\S+\.\S+$/.test(email)) return NextResponse.json({ error: "Please enter a valid email." }, { status: 400 });
  if (name.length < 2) return NextResponse.json({ error: "Please enter your name." }, { status: 400 });
  if (!slugs.length) return NextResponse.json({ error: "Your bag is empty." }, { status: 400 });

  const found = await db.select().from(products).where(inArray(products.slug, slugs));
  if (!found.length) return NextResponse.json({ error: "Those guides are no longer available." }, { status: 400 });

  const totals = computeTotals(
    found.map((p) => p.priceCents),
    promo,
  );
  const id = `ZK-${randomBytes(5).toString("hex").toUpperCase()}`;

  await db.transaction(async (tx) => {
    await tx.insert(orders).values({
      id,
      email,
      name,
      country,
      subtotalCents: totals.subtotal,
      discountCents: totals.discount,
      totalCents: totals.total,
      promoCode: totals.promoValid ? promo : null,
      status: "paid",
    });
    await tx.insert(orderItems).values(
      found.map((p) => ({ orderId: id, productId: p.id, slug: p.slug, title: p.title, priceCents: p.priceCents })),
    );
    await tx
      .update(products)
      .set({ salesCount: sql`${products.salesCount} + 1` })
      .where(
        inArray(
          products.id,
          found.map((p) => p.id),
        ),
      );
  });

  return NextResponse.json({ orderId: id, total: totals.total }, { status: 201 });
}
