import Image from "next/image";
import Link from "next/link";
import { BookCover } from "@/components/product/BookCover";
import { ProductCard } from "@/components/product/ProductCard";
import { Reveal } from "@/components/ui/Reveal";
import { Stars } from "@/components/ui/Stars";
import {
  getBestsellers,
  getCollections,
  getFeaturedProducts,
  getNewArrivals,
  getStoreStats,
  getTopReviews,
} from "@/lib/data";

export const dynamic = "force-dynamic";

const TOPICS = [
  "Budgeting",
  "First salary",
  "Investing",
  "CV & interviews",
  "Salary negotiation",
  "Overthinking",
  "Soft life",
  "Dating with intention",
  "Adult friendships",
  "Side hustles",
  "Content creation",
  "Digital planners",
];

const FAQ = [
  {
    q: "How do I receive my guides?",
    a: "Instantly. Right after checkout you'll land on a download page and get an email with permanent download links. No waiting, no shipping.",
  },
  {
    q: "What devices can I read them on?",
    a: "Everything. Our PDFs are optimised for phones, tablets and laptops, and planners/journals are hyperlinked for GoodNotes, Notability and Xodo. Prefer paper? Every page is print-ready on A4 and US Letter.",
  },
  {
    q: "What if it's not for me?",
    a: "We offer a 14-day 'no awkward questions' guarantee. If a guide doesn't help, email us and we'll refund you in full.",
  },
  {
    q: "Do bundle discounts stack with promo codes?",
    a: "Yes! Bundle savings (10% on 2 guides, 20% on 3+) apply automatically, then your promo code is applied on top.",
  },
  {
    q: "Can I gift a guide?",
    a: "Absolutely — just enter your friend's email at checkout and the download links will go straight to them.",
  },
];

export default async function HomePage() {
  const [collections, bestsellers, featured, newest, reviews, stats] = await Promise.all([
    getCollections(),
    getBestsellers(4),
    getFeaturedProducts(8),
    getNewArrivals(4),
    getTopReviews(6),
    getStoreStats(),
  ]);

  const heroBooks = featured.slice(0, 3);

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -right-40 -top-40 h-[520px] w-[520px] rounded-full bg-blush/60 blur-3xl" />
        <div className="pointer-events-none absolute -left-32 bottom-0 h-[380px] w-[380px] rounded-full bg-sand blur-3xl" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 pb-20 pt-10 sm:px-6 lg:grid-cols-[1.1fr_1fr] lg:gap-8 lg:px-8 lg:pb-28 lg:pt-16">
          <div>
            <p className="animate-fade-up inline-flex items-center gap-2 rounded-full border border-ink/15 bg-paper/60 px-4 py-1.5 text-xs font-medium backdrop-blur">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-clay" />
              Digital guides for ages 19–29
            </p>
            <h1
              className="animate-fade-up mt-6 font-serif text-[clamp(3rem,7.5vw,6.5rem)] font-medium leading-[0.92] tracking-[-0.03em]"
              style={{ animationDelay: "80ms" }}
            >
              Real talk,
              <br />
              <em className="font-normal text-clay">beautifully</em>
              <br />
              bound.
            </h1>
            <p
              className="animate-fade-up mt-7 max-w-lg text-lg leading-relaxed text-ink-soft"
              style={{ animationDelay: "160ms" }}
            >
              Money, career, mindset, love and side hustles — the stuff school skipped, in gorgeous, actionable PDFs
              you can start reading in 60 seconds.
            </p>
            <div className="animate-fade-up mt-9 flex flex-wrap items-center gap-3" style={{ animationDelay: "240ms" }}>
              <Link
                href="/shop"
                className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-4 text-sm font-semibold text-paper transition-all hover:bg-clay"
              >
                Shop the guides
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  className="transition-transform group-hover:translate-x-1"
                >
                  <path d="M5 12h14M13 6l6 6-6 6" />
                </svg>
              </Link>
              <Link
                href="/shop?tag=bestseller"
                className="rounded-full border border-ink/20 px-7 py-4 text-sm font-semibold transition-colors hover:border-ink hover:bg-paper"
              >
                See bestsellers
              </Link>
            </div>
            <div className="animate-fade-up mt-10 flex items-center gap-4" style={{ animationDelay: "320ms" }}>
              <div className="flex -space-x-2">
                {["#B4532A", "#5F7A5B", "#7C6A9E", "#C0606B", "#D9822B"].map((c, i) => (
                  <span
                    key={c}
                    className="grid h-9 w-9 place-items-center rounded-full border-2 border-cream text-xs font-semibold text-paper"
                    style={{ background: c }}
                  >
                    {"AJNKT"[i]}
                  </span>
                ))}
              </div>
              <div className="text-sm">
                <div className="flex items-center gap-2">
                  <Stars rating={stats.rating} />
                  <strong>{stats.rating.toFixed(1)}</strong>
                </div>
                <p className="text-muted">
                  Loved by {Math.round(stats.sold / 1000)}k+ readers in their twenties
                </p>
              </div>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-[520px]">
            <div className="animate-fade-in relative aspect-[4/5] overflow-hidden rounded-t-[999px] rounded-b-[40px] shadow-2xl">
              <Image
                src="/images/hero.jpg"
                alt="A Zikkytalk guide open on a tablet next to a latte and a goals journal"
                fill
                priority
                sizes="(max-width: 1024px) 90vw, 520px"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/30 via-transparent to-transparent" />
            </div>
            {heroBooks[0] && (
              <Link
                href={`/products/${heroBooks[0].slug}`}
                className="absolute -left-6 bottom-16 w-[34%] animate-float sm:-left-12"
                style={{ ["--r" as string]: "-8deg" }}
              >
                <BookCover title={heroBooks[0].title} author={heroBooks[0].author} cover={heroBooks[0].cover} />
              </Link>
            )}
            {heroBooks[1] && (
              <Link
                href={`/products/${heroBooks[1].slug}`}
                className="absolute -right-4 top-20 w-[28%] animate-float sm:-right-10"
                style={{ ["--r" as string]: "7deg", animationDelay: "1.5s" }}
              >
                <BookCover title={heroBooks[1].title} author={heroBooks[1].author} cover={heroBooks[1].cover} />
              </Link>
            )}
            <div className="absolute -bottom-6 right-6 rounded-2xl bg-paper/95 px-5 py-4 shadow-xl backdrop-blur sm:right-10">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-muted">Instant download</p>
              <p className="mt-1 font-serif text-lg">PDF · Tablet · Print</p>
            </div>
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <section className="overflow-hidden border-y border-ink/10 bg-paper py-5">
        <div className="flex w-max animate-marquee gap-10 whitespace-nowrap font-serif text-2xl italic text-ink-soft">
          {[...TOPICS, ...TOPICS].map((t, i) => (
            <span key={i} className="flex items-center gap-10">
              {t}
              <span className="text-clay not-italic">✦</span>
            </span>
          ))}
        </div>
      </section>

      {/* COLLECTIONS */}
      <section className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <Reveal className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-clay">Featured collections</p>
            <h2 className="mt-3 max-w-xl font-serif text-4xl leading-tight sm:text-5xl">
              Pick the part of life you&apos;re levelling up.
            </h2>
          </div>
          <Link href="/shop" className="text-sm font-semibold underline underline-offset-4 hover:text-clay">
            View all {collections.reduce((a, c) => a + c.productCount, 0)} guides
          </Link>
        </Reveal>

        <div className="mt-12 grid auto-rows-[260px] gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:auto-rows-[300px]">
          {collections.map((c, i) => (
            <Reveal
              key={c.slug}
              delay={i * 80}
              className={i === 0 ? "sm:col-span-2 sm:row-span-2" : i === 3 ? "lg:col-span-2" : ""}
            >
              <Link
                href={`/collections/${c.slug}`}
                className="group relative block h-full overflow-hidden rounded-[28px]"
              >
                <Image
                  src={c.image}
                  alt={c.name}
                  fill
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 40vw"
                  className="object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/20 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-6 text-paper">
                  <div>
                    <p className="text-xs font-medium uppercase tracking-[0.2em] text-paper/70">
                      {c.productCount} guides
                    </p>
                    <h3 className={`mt-1 font-serif ${i === 0 ? "text-4xl sm:text-5xl" : "text-3xl"}`}>{c.name}</h3>
                    <p className="mt-1 text-sm text-paper/80">{c.tagline}</p>
                  </div>
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-paper text-ink transition-all duration-500 group-hover:rotate-[-45deg] group-hover:bg-clay group-hover:text-paper">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M5 12h14M13 6l6 6-6 6" />
                    </svg>
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* BESTSELLERS */}
      <section className="mx-auto max-w-7xl px-4 pb-24 sm:px-6 lg:px-8">
        <Reveal className="flex items-end justify-between gap-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-clay">Most loved</p>
            <h2 className="mt-3 font-serif text-4xl sm:text-5xl">Bestsellers</h2>
          </div>
          <Link href="/shop?sort=popular" className="text-sm font-semibold underline underline-offset-4 hover:text-clay">
            Shop all
          </Link>
        </Reveal>
        <div className="mt-12 grid grid-cols-1 gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-4">
          {bestsellers.map((p, i) => (
            <Reveal key={p.id} delay={i * 90}>
              <ProductCard product={p} priority />
            </Reveal>
          ))}
        </div>
      </section>

      {/* STORY */}
      <section className="bg-paper">
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 py-24 sm:px-6 lg:grid-cols-2 lg:px-8">
          <Reveal className="relative">
            <div className="relative aspect-[4/5] overflow-hidden rounded-[32px]">
              <Image
                src="/images/lifestyle-reading.jpg"
                alt="Reading a Zikkytalk guide on a tablet in a cafe"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
            <div className="absolute -bottom-8 -right-2 w-[45%] overflow-hidden rounded-[24px] border-8 border-paper shadow-xl sm:-right-8">
              <div className="relative aspect-square">
                <Image src="/images/lifestyle-desk.jpg" alt="Digital planner on a tablet" fill sizes="25vw" className="object-cover" />
              </div>
            </div>
          </Reveal>
          <Reveal delay={120}>
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-clay">Why Zikkytalk</p>
            <h2 className="mt-3 font-serif text-4xl leading-tight sm:text-5xl">
              Like a big sister who&apos;s figured it out — <em className="text-clay">and wrote it all down.</em>
            </h2>
            <p className="mt-6 text-lg leading-relaxed text-ink-soft">
              Every guide is written by people who&apos;ve lived it, reviewed by experts, and designed to be used — not
              just read. Short chapters, real scripts, printable worksheets.
            </p>
            <div className="mt-10 grid gap-6 sm:grid-cols-2">
              {[
                { k: "01", t: "Actually actionable", d: "Checklists, scripts and templates on every other page." },
                { k: "02", t: "Designed to delight", d: "Editorial layouts you'll want to read on a Sunday." },
                { k: "03", t: "Any device", d: "Phone, tablet, GoodNotes, or printed and bound." },
                { k: "04", t: "Zero-risk", d: "14-day money-back guarantee, no awkward questions." },
              ].map((f) => (
                <div key={f.k} className="border-t border-ink/15 pt-4">
                  <p className="font-serif text-sm text-clay">{f.k}</p>
                  <p className="mt-1 font-serif text-xl">{f.t}</p>
                  <p className="mt-1 text-sm text-muted">{f.d}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* FEATURED SCROLLER */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal className="flex items-end justify-between gap-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.25em] text-clay">Editor&apos;s picks</p>
              <h2 className="mt-3 font-serif text-4xl sm:text-5xl">Start here</h2>
            </div>
            <p className="hidden text-sm text-muted sm:block">Scroll →</p>
          </Reveal>
        </div>
        <div className="no-scrollbar mt-10 flex snap-x snap-mandatory gap-6 overflow-x-auto px-4 pb-4 sm:px-6 lg:px-[max(2rem,calc((100vw-80rem)/2+2rem))]">
          {featured.map((p) => (
            <div key={p.id} className="w-[78%] shrink-0 snap-start sm:w-[42%] lg:w-[23%]">
              <ProductCard product={p} />
            </div>
          ))}
        </div>
      </section>

      {/* BUNDLE BANNER */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Reveal className="grain relative overflow-hidden rounded-[36px] bg-ink px-6 py-16 text-paper sm:px-12 lg:px-16">
          <div className="pointer-events-none absolute -right-20 -top-20 h-80 w-80 rounded-full bg-clay/40 blur-3xl" />
          <div className="relative grid items-center gap-12 lg:grid-cols-2">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.25em] text-blush">Bundle &amp; save</p>
              <h2 className="mt-4 font-serif text-4xl leading-tight sm:text-6xl">
                Build your <em className="text-blush">twenties toolkit.</em>
              </h2>
              <p className="mt-5 max-w-md text-paper/70">
                Mix any guides — save <strong className="text-paper">10% on two</strong> and{" "}
                <strong className="text-paper">20% on three or more</strong>. Applied automatically at checkout.
              </p>
              <Link
                href="/shop"
                className="mt-8 inline-flex items-center gap-2 rounded-full bg-paper px-7 py-4 text-sm font-semibold text-ink transition-colors hover:bg-blush"
              >
                Build my bundle
              </Link>
            </div>
            <div className="relative mx-auto h-[320px] w-full max-w-md sm:h-[380px]">
              {bestsellers.slice(0, 3).map((p, i) => (
                <div
                  key={p.id}
                  className="absolute top-1/2 w-[42%] -translate-y-1/2 transition-transform duration-700 hover:-translate-y-[58%]"
                  style={{
                    left: `${8 + i * 25}%`,
                    transform: `translateY(-50%) rotate(${(i - 1) * 9}deg)`,
                    zIndex: i === 1 ? 3 : 1,
                  }}
                >
                  <BookCover title={p.title} author={p.author} cover={p.cover} />
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </section>

      {/* NEW ARRIVALS */}
      <section className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <Reveal className="flex items-end justify-between gap-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-clay">Fresh drops</p>
            <h2 className="mt-3 font-serif text-4xl sm:text-5xl">New in</h2>
          </div>
          <Link href="/shop?tag=new" className="text-sm font-semibold underline underline-offset-4 hover:text-clay">
            See all new
          </Link>
        </Reveal>
        <div className="mt-12 grid grid-cols-1 gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-4">
          {newest.map((p, i) => (
            <Reveal key={p.id} delay={i * 90}>
              <ProductCard product={p} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* REVIEWS */}
      <section className="bg-sand/60 py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal className="text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-clay">
              {stats.reviews}+ verified reviews
            </p>
            <h2 className="mx-auto mt-3 max-w-2xl font-serif text-4xl leading-tight sm:text-5xl">
              &ldquo;Genuinely life-changing&rdquo; — the group chat
            </h2>
          </Reveal>
          <div className="mt-14 columns-1 gap-6 sm:columns-2 lg:columns-3">
            {reviews.map((r, i) => (
              <Reveal key={r.review.id} delay={i * 70} className="mb-6 break-inside-avoid">
                <figure className="rounded-[24px] bg-paper p-7 shadow-sm transition-shadow hover:shadow-lg">
                  <Stars rating={r.review.rating} />
                  <p className="mt-4 font-serif text-xl leading-snug">{r.review.title}</p>
                  <blockquote className="mt-3 text-sm leading-relaxed text-ink-soft">{r.review.body}</blockquote>
                  <figcaption className="mt-6 flex items-center gap-3 border-t border-ink/10 pt-5">
                    <div className="w-9 shrink-0">
                      <BookCover title={r.productTitle} cover={r.cover} shadow={false} />
                    </div>
                    <div className="text-xs">
                      <p className="font-semibold">
                        {r.review.author}, {r.review.age} · {r.review.location}
                      </p>
                      <Link href={`/products/${r.productSlug}`} className="text-muted hover:text-clay">
                        on {r.productTitle}
                      </Link>
                    </div>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="mx-auto grid max-w-7xl gap-12 px-4 pt-24 sm:px-6 lg:grid-cols-[1fr_1.5fr] lg:px-8">
        <Reveal>
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-clay">Good questions</p>
          <h2 className="mt-3 font-serif text-4xl sm:text-5xl">FAQ</h2>
          <p className="mt-4 max-w-sm text-muted">
            Still curious? Email{" "}
            <a href="mailto:hello@zikkytalk.com" className="underline underline-offset-4">
              hello@zikkytalk.com
            </a>{" "}
            — a real human replies within a day.
          </p>
        </Reveal>
        <Reveal delay={100} className="divide-y divide-ink/10 border-y border-ink/10">
          {FAQ.map((f) => (
            <details key={f.q} className="group py-6">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-6 font-serif text-xl">
                {f.q}
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-ink/20 transition-transform duration-300 group-open:rotate-45">
                  +
                </span>
              </summary>
              <p className="mt-4 max-w-2xl leading-relaxed text-ink-soft">{f.a}</p>
            </details>
          ))}
        </Reveal>
      </section>
    </>
  );
}
