import { sql } from "drizzle-orm";
import { db, pool } from "./index";
import { collections, products, reviews } from "./schema";
import { seedCollections, seedProducts } from "./seed-data";

const DDL = `
CREATE TABLE IF NOT EXISTS collections (
  id serial PRIMARY KEY,
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  tagline text NOT NULL,
  description text NOT NULL,
  image text NOT NULL,
  accent text NOT NULL,
  sort integer NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS products (
  id serial PRIMARY KEY,
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  subtitle text NOT NULL,
  description text NOT NULL,
  collection_slug text NOT NULL,
  price_cents integer NOT NULL,
  compare_at_cents integer,
  pages integer NOT NULL,
  level text NOT NULL,
  format text NOT NULL,
  author text NOT NULL,
  highlights jsonb NOT NULL,
  toc jsonb NOT NULL,
  cover jsonb NOT NULL,
  tags jsonb NOT NULL,
  featured boolean NOT NULL DEFAULT false,
  bestseller boolean NOT NULL DEFAULT false,
  is_new boolean NOT NULL DEFAULT false,
  sales_count integer NOT NULL DEFAULT 0,
  created_at timestamp NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS reviews (
  id serial PRIMARY KEY,
  product_id integer NOT NULL,
  author text NOT NULL,
  age integer,
  location text,
  rating integer NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  verified boolean NOT NULL DEFAULT false,
  created_at timestamp NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS orders (
  id text PRIMARY KEY,
  email text NOT NULL,
  name text NOT NULL,
  country text NOT NULL,
  subtotal_cents integer NOT NULL,
  discount_cents integer NOT NULL,
  total_cents integer NOT NULL,
  promo_code text,
  status text NOT NULL DEFAULT 'paid',
  created_at timestamp NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS order_items (
  id serial PRIMARY KEY,
  order_id text NOT NULL,
  product_id integer NOT NULL,
  slug text NOT NULL,
  title text NOT NULL,
  price_cents integer NOT NULL
);
`;

const daysAgo = (d: number) => new Date(Date.now() - d * 86_400_000);

async function run() {
  await pool.query(DDL);

  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products);
  if (count > 0) return;

  await db.insert(collections).values(seedCollections).onConflictDoNothing();

  for (const p of seedProducts) {
    const { reviews: productReviews, daysAgo: age, ...rest } = p;
    const [inserted] = await db
      .insert(products)
      .values({ ...rest, createdAt: daysAgo(age) })
      .onConflictDoNothing()
      .returning({ id: products.id });
    if (!inserted) continue;
    if (productReviews.length) {
      await db.insert(reviews).values(
        productReviews.map((r) => ({
          productId: inserted.id,
          author: r.author,
          age: r.age,
          location: r.location,
          rating: r.rating,
          title: r.title,
          body: r.body,
          verified: true,
          createdAt: daysAgo(r.daysAgo),
        })),
      );
    }
  }
}

const globalForBoot = globalThis as typeof globalThis & {
  __zikkyBoot?: Promise<void>;
};

export function ensureDb(): Promise<void> {
  if (!globalForBoot.__zikkyBoot) {
    globalForBoot.__zikkyBoot = run().catch((err) => {
      globalForBoot.__zikkyBoot = undefined;
      throw err;
    });
  }
  return globalForBoot.__zikkyBoot;
}
