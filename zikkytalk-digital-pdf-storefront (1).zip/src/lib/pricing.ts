export const formatPrice = (cents: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(cents / 100);

export const PROMO_CODES: Record<string, { label: string; type: "percent" | "fixed"; value: number }> = {
  ZIKKY10: { label: "10% off with ZIKKY10", type: "percent", value: 10 },
  WELCOME5: { label: "$5 off your first order", type: "fixed", value: 500 },
  TWENTIES: { label: "15% off — Twenties Club", type: "percent", value: 15 },
};

export function bundlePercent(count: number) {
  if (count >= 3) return 20;
  if (count === 2) return 10;
  return 0;
}

export function computeTotals(prices: number[], promo?: string | null) {
  const subtotal = prices.reduce((a, b) => a + b, 0);
  const bPct = bundlePercent(prices.length);
  const bundleDiscount = Math.round((subtotal * bPct) / 100);
  const afterBundle = subtotal - bundleDiscount;
  const code = promo ? PROMO_CODES[promo.trim().toUpperCase()] : undefined;
  let promoDiscount = 0;
  if (code) {
    promoDiscount =
      code.type === "percent" ? Math.round((afterBundle * code.value) / 100) : Math.min(code.value, afterBundle);
  }
  const discount = bundleDiscount + promoDiscount;
  return {
    subtotal,
    bundlePercent: bPct,
    bundleDiscount,
    promoDiscount,
    promoValid: !!code,
    promoLabel: code?.label ?? null,
    discount,
    total: Math.max(0, subtotal - discount),
  };
}
