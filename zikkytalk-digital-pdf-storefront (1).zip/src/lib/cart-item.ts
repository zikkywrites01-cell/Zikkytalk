import type { CartItem } from "@/components/cart/CartProvider";
import type { CoverTheme } from "@/db/schema";

type ProductLike = {
  id: number;
  slug: string;
  title: string;
  subtitle: string;
  author: string;
  priceCents: number;
  compareAtCents: number | null;
  pages: number;
  format: string;
  cover: CoverTheme;
};

export const toCartItem = (p: ProductLike): CartItem => ({
  productId: p.id,
  slug: p.slug,
  title: p.title,
  subtitle: p.subtitle,
  author: p.author,
  priceCents: p.priceCents,
  compareAtCents: p.compareAtCents,
  pages: p.pages,
  format: p.format,
  cover: p.cover,
});

export const COLLECTION_NAMES: Record<string, string> = {
  "money-moves": "Money Moves",
  "career-glow-up": "Career Glow-Up",
  "mind-and-wellness": "Mind & Wellness",
  "love-and-friendships": "Love & Friendships",
  "side-hustle-lab": "Side Hustle Lab",
};
