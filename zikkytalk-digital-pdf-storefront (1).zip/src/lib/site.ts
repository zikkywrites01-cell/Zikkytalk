// Public URL of the deployed store. Set NEXT_PUBLIC_SITE_URL (e.g. https://zikkytalk.com)
// in your hosting provider. Falls back to Vercel's automatic URL, then localhost.
export const siteUrl = (
  process.env.NEXT_PUBLIC_SITE_URL ||
  (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : "") ||
  (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "") ||
  "http://localhost:3000"
).replace(/\/$/, "");
