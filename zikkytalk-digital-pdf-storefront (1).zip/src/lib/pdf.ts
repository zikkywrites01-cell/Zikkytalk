// Minimal, dependency-free PDF writer used to deliver licensed guide files.

type Rgb = [number, number, number];

const hexToRgb = (hex: string): Rgb => {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
};

const ascii = (s: string) =>
  s
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/\u2026/g, "...")
    .replace(/[^\x20-\x7E]/g, "");

const esc = (s: string) => ascii(s).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");

const wrap = (text: string, size: number, width: number, factor = 0.5) => {
  const max = Math.floor(width / (size * factor));
  const words = ascii(text).split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const w of words) {
    if ((line + " " + w).trim().length > max) {
      if (line) lines.push(line);
      line = w;
    } else line = (line + " " + w).trim();
  }
  if (line) lines.push(line);
  return lines;
};

class Page {
  ops: string[] = [];
  rect(x: number, y: number, w: number, h: number, c: Rgb) {
    this.ops.push(`${c.map((v) => v.toFixed(3)).join(" ")} rg ${x} ${y} ${w} ${h} re f`);
  }
  circle(cx: number, cy: number, r: number, c: Rgb) {
    const k = 0.5523 * r;
    this.ops.push(
      `${c.map((v) => v.toFixed(3)).join(" ")} rg ${cx + r} ${cy} m ${cx + r} ${cy + k} ${cx + k} ${cy + r} ${cx} ${cy + r} c ${cx - k} ${cy + r} ${cx - r} ${cy + k} ${cx - r} ${cy} c ${cx - r} ${cy - k} ${cx - k} ${cy - r} ${cx} ${cy - r} c ${cx + k} ${cy - r} ${cx + r} ${cy - k} ${cx + r} ${cy} c f`,
    );
  }
  text(x: number, y: number, s: string, font: string, size: number, c: Rgb) {
    this.ops.push(`BT ${c.map((v) => v.toFixed(3)).join(" ")} rg /${font} ${size} Tf ${x} ${y} Td (${esc(s)}) Tj ET`);
  }
  para(x: number, y: number, s: string, font: string, size: number, c: Rgb, width: number, leading = 1.45, factor = 0.5) {
    const lines = wrap(s, size, width, factor);
    lines.forEach((l, i) => this.text(x, y - i * size * leading, l, font, size, c));
    return y - lines.length * size * leading;
  }
}

export type GuidePdfInput = {
  title: string;
  subtitle: string;
  author: string;
  description: string;
  highlights: string[];
  toc: { title: string; pages: string }[];
  cover: { bg: string; fg: string; accent: string };
  licensee: string;
  orderId: string;
};

export function buildGuidePdf(g: GuidePdfInput): Buffer {
  const W = 595;
  const H = 842;
  const bg = hexToRgb(g.cover.bg);
  const fg = hexToRgb(g.cover.fg);
  const accent = hexToRgb(g.cover.accent);
  const ink: Rgb = [0.11, 0.09, 0.08];
  const muted: Rgb = [0.46, 0.41, 0.37];
  const paper: Rgb = [1, 0.992, 0.973];

  // Cover
  const cover = new Page();
  cover.rect(0, 0, W, H, bg);
  cover.circle(470, 120, 210, accent);
  cover.circle(470, 120, 120, bg);
  cover.circle(470, 120, 60, accent);
  cover.text(56, H - 72, "ZIKKYTALK", "F2", 11, fg);
  cover.text(W - 100, H - 72, "PDF GUIDE", "F2", 9, fg);
  let y = H - 190;
  for (const line of wrap(g.title, 54, W - 112, 0.48)) {
    cover.text(56, y, line, "F3", 54, fg);
    y -= 58;
  }
  y = cover.para(56, y - 14, g.subtitle, "F4", 18, fg, W - 160, 1.35, 0.45);
  cover.text(56, 64, g.author.toUpperCase(), "F2", 11, fg);

  // Contents
  const toc = new Page();
  toc.rect(0, 0, W, H, paper);
  toc.rect(0, H - 8, W, 8, accent);
  toc.text(56, H - 80, "CONTENTS", "F2", 10, accent);
  toc.text(56, H - 130, g.title, "F3", 32, ink);
  y = H - 200;
  g.toc.forEach((c, i) => {
    toc.text(56, y, String(i + 1).padStart(2, "0"), "F3", 18, accent);
    toc.text(100, y, c.title, "F1", 14, ink);
    toc.text(W - 120, y, `pp. ${c.pages}`, "F1", 11, muted);
    toc.rect(56, y - 16, W - 112, 0.6, [0.88, 0.85, 0.8]);
    y -= 44;
  });
  y -= 30;
  toc.rect(56, y - 20 - g.highlights.length * 26, W - 112, 50 + g.highlights.length * 26, bg);
  toc.text(76, y, "INSIDE YOU'LL FIND", "F2", 10, accent);
  y -= 30;
  g.highlights.forEach((h) => {
    toc.circle(82, y + 4, 3, accent);
    toc.text(96, y, h, "F1", 12, fg);
    y -= 26;
  });

  // Welcome
  const intro = new Page();
  intro.rect(0, 0, W, H, paper);
  intro.text(56, H - 80, "WELCOME", "F2", 10, accent);
  intro.text(56, H - 130, "Before you begin", "F3", 32, ink);
  y = intro.para(56, H - 180, g.description, "F1", 12.5, ink, W - 112, 1.6);
  y = intro.para(
    56,
    y - 20,
    "Read one chapter at a time, do the exercises as you go, and come back to the checklists whenever you need a reset. Small steps, repeated, change everything. - Zikky",
    "F4",
    14,
    muted,
    W - 112,
    1.5,
    0.45,
  );
  intro.rect(56, 90, W - 112, 0.6, [0.88, 0.85, 0.8]);
  intro.text(56, 68, `Licensed to ${g.licensee}  -  Order ${g.orderId}`, "F1", 9, muted);
  intro.text(56, 54, "For personal use only. Please don't share or resell. Thank you for supporting independent creators.", "F1", 9, muted);

  const pages = [cover, toc, intro];

  const objects: string[] = [];
  const add = (s: string) => objects.push(s) && objects.length;
  add("<< /Type /Catalog /Pages 2 0 R >>");
  add("PAGES_PLACEHOLDER");
  add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>");
  add("<< /Type /Font /Subtype /Type1 /BaseFont /Times-Bold >>");
  add("<< /Type /Font /Subtype /Type1 /BaseFont /Times-Italic >>");
  const pageIds: number[] = [];
  for (const p of pages) {
    const stream = p.ops.join("\n");
    const contentId = add(`<< /Length ${Buffer.byteLength(stream, "latin1")} >>\nstream\n${stream}\nendstream`);
    pageIds.push(
      add(
        `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R /F4 6 0 R >> >> /Contents ${contentId} 0 R >>`,
      ),
    );
  }
  objects[1] = `<< /Type /Pages /Kids [${pageIds.map((i) => `${i} 0 R`).join(" ")}] /Count ${pageIds.length} >>`;
  const info = add(`<< /Title (${esc(g.title)}) /Author (${esc(g.author)}) /Producer (Zikkytalk) >>`);

  let out = "%PDF-1.4\n";
  const offsets: number[] = [];
  objects.forEach((o, i) => {
    offsets.push(Buffer.byteLength(out, "latin1"));
    out += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const xref = Buffer.byteLength(out, "latin1");
  out += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  out += offsets.map((o) => `${String(o).padStart(10, "0")} 00000 n \n`).join("");
  out += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R /Info ${info} 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(out, "latin1");
}
