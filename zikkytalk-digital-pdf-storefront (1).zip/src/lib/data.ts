import "server-only";
import { and, asc, desc, eq, gte, inArray, lte, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { collections, products, reviews } from "@/db/schema";

export type Product = typeof products.$inferSelect & {
  rating: number;
  reviewCount: number;
};
export type Collection = typeof collections.$inferSelect;
export type Review = typeof reviews.$inferSelect;

const ratingAgg = db
  .select({
    productId: reviews.productId,
    rating: sql<number>`round(avg(${reviews.rating})::numeric, 2)::float`.as("rating"),
    reviewCount: sql<number>`count(*)::int`.as("review_count"),
  })
  .from(reviews)
  .groupBy(reviews.productId)
  .as("ra");

function baseQuery() {
  return db
    .select({
      product: products,
      rating: sql<number>`coalesce(${ratingAgg.rating}, 0)`,
      reviewCount: sql<number>`coalesce(${ratingAgg.reviewCount}, 0)`,
    })
    .from(products)
    .leftJoin(ratingAgg, eq(ratingAgg.productId, products.id));
}

type Row = { product: typeof products.$inferSelect; rating: number; reviewCount: number };
const toProduct = (r: Row): Product => ({
  ...r.product,
  rating: Number(r.rating),
  reviewCount: Number(r.reviewCount),
});

export async function getCollections(): Promise<(Collection & { productCount: number })[]> {
  await ensureDb();
  const rows = await db
    .select({
      c: collections,
      productCount: sql<number>`(select count(*)::int from products p where p.collection_slug = ${collections.slug})`,
    })
    .from(collections)
    .orderBy(asc(collections.sort));
  return rows.map((r) => ({ ...r.c, productCount: Number(r.productCount) }));
}

export async function getCollection(slug: string) {
  await ensureDb();
  const [c] = await db.select().from(collections).where(eq(collections.slug, slug));
  return c ?? null;
}

export type ShopFilters = {
  collection?: string[];
  format?: string[];
  level?: string[];
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  q?: string;
  sort?: string;
  tag?: "new" | "bestseller" | "sale";
};

export async function getProducts(f: ShopFilters = {}): Promise<Product[]> {
  await ensureDb();
  const where: SQL[] = [];
  if (f.collection?.length) where.push(inArray(products.collectionSlug, f.collection));
  if (f.format?.length) where.push(inArray(products.format, f.format));
  if (f.level?.length) where.push(inArray(products.level, f.level));
  if (f.minPrice != null) where.push(gte(products.priceCents, f.minPrice * 100));
  if (f.maxPrice != null) where.push(lte(products.priceCents, f.maxPrice * 100));
  if (f.tag === "new") where.push(eq(products.isNew, true));
  if (f.tag === "bestseller") where.push(eq(products.bestseller, true));
  if (f.tag === "sale") where.push(sql`${products.compareAtCents} is not null`);
  if (f.q) {
    const like = `%${f.q.toLowerCase()}%`;
    where.push(
      sql`(lower(${products.title}) like ${like} or lower(${products.subtitle}) like ${like} or lower(${products.tags}::text) like ${like})`,
    );
  }
  if (f.minRating) where.push(sql`coalesce(${ratingAgg.rating}, 0) >= ${f.minRating}`);

  let order: SQL[];
  switch (f.sort) {
    case "price-asc":
      order = [asc(products.priceCents)];
      break;
    case "price-desc":
      order = [desc(products.priceCents)];
      break;
    case "newest":
      order = [desc(products.createdAt)];
      break;
    case "rating":
      order = [sql`coalesce(${ratingAgg.rating}, 0) desc`, sql`coalesce(${ratingAgg.reviewCount}, 0) desc`];
      break;
    default:
      order = [desc(products.featured), desc(products.salesCount)];
  }

  const rows = await baseQuery()
    .where(where.length ? and(...where) : undefined)
    .orderBy(...order);
  return rows.map(toProduct);
}

export async function getFeaturedProducts(limit = 8) {
  await ensureDb();
  const rows = await baseQuery()
    .where(eq(products.featured, true))
    .orderBy(desc(products.salesCount))
    .limit(limit);
  return rows.map(toProduct);
}

export async function getBestsellers(limit = 4) {
  await ensureDb();
  const rows = await baseQuery().orderBy(desc(products.salesCount)).limit(limit);
  return rows.map(toProduct);
}

export async function getNewArrivals(limit = 4) {
  await ensureDb();
  const rows = await baseQuery().orderBy(desc(products.createdAt)).limit(limit);
  return rows.map(toProduct);
}

export async function getProduct(slug: string) {
  await ensureDb();
  const [row] = await baseQuery().where(eq(products.slug, slug));
  return row ? toProduct(row) : null;
}

export async function getRelated(p: Product, limit = 4) {
  const rows = await baseQuery()
    .where(and(eq(products.collectionSlug, p.collectionSlug), sql`${products.id} <> ${p.id}`))
    .orderBy(desc(products.salesCount))
    .limit(limit);
  const list = rows.map(toProduct);
  if (list.length < limit) {
    const more = await baseQuery()
      .where(sql`${products.collectionSlug} <> ${p.collectionSlug}`)
      .orderBy(desc(products.salesCount))
      .limit(limit - list.length);
    list.push(...more.map(toProduct));
  }
  return list;
}

export async function getReviews(productId: number) {
  await ensureDb();
  return db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, productId))
    .orderBy(desc(reviews.createdAt));
}

export async function getTopReviews(limit = 6) {
  await ensureDb();
  return db
    .select({
      review: reviews,
      productTitle: products.title,
      productSlug: products.slug,
      cover: products.cover,
    })
    .from(reviews)
    .innerJoin(products, eq(products.id, reviews.productId))
    .where(eq(reviews.rating, 5))
    .orderBy(sql`length(${reviews.body}) desc`)
    .limit(limit);
}

export async function getStoreStats() {
  await ensureDb();
  const [s] = await db
    .select({
      sold: sql<number>`(select coalesce(sum(sales_count),0)::int from products)`,
      reviews: sql<number>`(select count(*)::int from reviews)`,
      rating: sql<number>`(select round(avg(rating)::numeric,1)::float from reviews)`,
    })
    .from(sql`(select 1) as one`);
  return { sold: Number(s.sold), reviews: Number(s.reviews), rating: Number(s.rating) };
}
